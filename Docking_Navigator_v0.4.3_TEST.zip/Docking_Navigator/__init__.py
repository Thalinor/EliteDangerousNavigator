"""Docking Navigator — standalone EDMC package plugin."""
