"""Neutron Highway Navigator: independent route planning, progress and clipboard UI.

By Commander Thalinor and collaborators. See README.txt for terms and sources.
"""
from __future__ import annotations
import csv
import json
import math
import os
import queue
import re
import shutil
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from typing import Any
import tkinter as tk
import tkinter.font as tkfont
from tkinter import ttk
from tkinter import filedialog, messagebox
from config import config
from EDMCLogging import get_main_logger

TITLE = "Neutron Highway Navigator"
VERSION = "1.4.3"
logger = get_main_logger()
PLUGIN_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = PLUGIN_DIR
STATE_PATH = os.path.join(DATA_DIR,"navigator_state.json")
ROUTE_PATH = os.path.join(DATA_DIR,"active_route.json")
SETTINGS_PATH = os.path.join(DATA_DIR,"settings.json")
_app_frame = _current_label = _next_label = _end_label = None
_done_label = _left_label = _systems_popup = None
_copy_current_button = _copy_next_button = _copy_end_button = None
_title_label = _collapse_button = _gear_image = _header_frame = None
_status_label = _cog_button = _route_rows = []
_route_systems = []
_route_index = -1
_snapshot = {"schema_version":1,"source":"EDMarketConnector","location":{},"ship":{},"route":{}}
_theme_pending = None
_theme_bindings = []
_theme_controls = []
_status_expiry = None
_pace_anchor = None
_pace_samples = []
_last_loadout = None
_plot_popup = None
_plot_close_callback = None
_stopped = False
DEFAULT_SETTINGS = {"collapsed":False,"plot_efficiency":70,"plot_last_end":"",
                    "plot_type": "neutron", "riches_radius": 25, "riches_max_systems": 25, "riches_min_value": 500000, "riches_max_ls": 50000, "fuel_safety": "normal",
                    "galaxy_algorithm": "optimistic", "show_progress_bar": True, "force_theme_icons": False,
                    "eta_minutes_per_jump": 2.0}
_settings = dict(DEFAULT_SETTINGS)
SPANSH_ROUTE_URL = "https://spansh.co.uk/api/route"
SPANSH_RESULTS_URL = "https://spansh.co.uk/api/results/"
SPANSH_NAMES_URL = "https://spansh.co.uk/api/systems/field_values/system_names"
SPANSH_TIMEOUT = 15
SPANSH_MAX_WAIT = 120
MAX_SANE_RANGE = 150.0

class _PlotCancelled(Exception):
    pass


ABOUT_TEXT = (
    "Plugin coded collaboratively with Claude, ChatGPT and Gemini by Commander Thalinor.\n"
    "\n"
    "Elite Dangerous Commander Name: Thalinor\n"
    "eMail: thalinor @ gmail.com\n"
    "\n"
    "You can use this plugin freely for your own personal, non-commercial use. "
    "You can distribute it freely as long as the code has not been modified and you do "
    "not claim it's your own work. You may NOT sell this plugin, use this plugin for "
    "commercial use, or use its code in your projects without prior authorization.\n"
    "\n"
    "Plot New Route uses Spansh's plotters (spansh.co.uk) - thank you, CMDR Spansh.\n"
    "Galaxy Plotter FSD stats: coriolis-data (EDCD). Game data (c) Frontier Developments plc.\n"
    "\n"
    "Human + AI = Future"
)

_RECENT_SHIPS = {          # in case an older EDMC doesn't know the newest ships yet
    "explorer_nx": "Caspian Explorer", "python_nx": "Python Mk II", "mandalay": "Mandalay",
    "corsair": "Corsair", "cobramkv": "Cobra Mk V", "panthermkii": "Panther Clipper Mk II",
    "type8": "Type-8 Transporter", "smallcombat01_nx": "Kestrel Mk II",
    "mediumtransport01": "Lynx Highliner", "lakonminer": "Type-11 Prospector",
    "typex_2": "Alliance Crusader",
}

_GEARS = (
    (0.38, 0.40, 0.24, 0.33, 0.10, 8, 0.0),
    (0.73, 0.74, 0.13, 0.20, 0.055, 6, 0.5),
)

def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")

def _json_safe(value: Any) -> bool:
    try:
        json.dumps(value, allow_nan=False)
        return True
    except (TypeError, ValueError):
        return False

def _copy_present(source: dict[str, Any], keys: tuple[str, ...]) -> dict[str, Any]:
    return {key: source[key] for key in keys if key in source and _json_safe(source[key])}

def _write_json(path: str, data: dict[str, Any]) -> None:
    fd, temporary = tempfile.mkstemp(prefix="neutron_nav_", suffix=".tmp", dir=DATA_DIR)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as stream:
            json.dump(data, stream, ensure_ascii=False, indent=2, allow_nan=False)
            stream.write("\n")
        # Windows refuses to replace a file another program has open (Explorer
        # preview, an editor, a scanner), so retry briefly, then fall back to
        # writing in place, which works when the other program only reads.
        for attempt in range(5):
            try:
                os.replace(temporary, path)
                return
            except PermissionError:
                time.sleep(0.1 * (attempt + 1))
        with open(temporary, encoding="utf-8") as source, \
                open(path, "w", encoding="utf-8", newline="\n") as target:
            target.write(source.read())
        os.unlink(temporary)
    except Exception:
        try:
            os.unlink(temporary)
        except OSError:
            pass
        raise

def _current_system() -> str | None:
    return _route_systems[_route_index] if 0 <= _route_index < len(_route_systems) else None

def _next_system() -> str | None:
    index = _route_index + 1
    return _route_systems[index] if 0 <= index < len(_route_systems) else None

def _end_system() -> str | None:
    return _route_systems[-1] if _route_systems else None

def _jump_counts() -> tuple[int, int]:
    if not _route_systems:
        return 0, 0
    done = max(0, _route_index)
    return done, max(0, len(_route_systems) - 1 - done)

def _sync_route_snapshot() -> None:
    done, left = _jump_counts()
    _snapshot["route"] = {
        "loaded": bool(_route_systems), "waypoints_total": len(_route_systems),
        "current_index": _route_index, "current_system": _current_system(),
        "next_system": _next_system(), "end_system": _end_system(),
        "jumps_done": done, "jumps_left": left,
    }

def _persist_route() -> None:
    _write_json(ROUTE_PATH, {"schema_version": 2, "systems": _route_systems, "current_index": _route_index,
                             "kind": _route_kind, "bodies": _route_bodies})

def _load_saved_route() -> None:
    global _route_systems, _route_index, _route_kind, _route_bodies
    try:
        with open(ROUTE_PATH, encoding="utf-8-sig") as stream:
            saved = json.load(stream)
        systems = saved.get("systems", [])
        if not isinstance(systems, list) or not all(isinstance(name, str) and name.strip() for name in systems):
            raise ValueError("Saved route contains invalid system names.")
        index = int(saved.get("current_index", 0))
        _route_systems = systems
        _route_kind = saved.get("kind") if saved.get("kind") in ROUTE_KINDS else "neutron"
        bodies = saved.get("bodies")
        _route_bodies = bodies if isinstance(bodies, dict) else {}
        # With no reached stop yet, the first CSV system is the route's join point.
        _route_index = max(0, min(index, len(systems) - 1)) if systems else -1
    except FileNotFoundError:
        pass
    except (OSError, ValueError, TypeError, AttributeError):
        logger.exception("Could not restore neutron route")

def _save() -> None:
    _sync_route_snapshot()
    _refresh_route_label()
    _snapshot["updated_at_utc"] = _utc_now()
    try:
        _write_json(STATE_PATH, _snapshot)
    except Exception:
        logger.exception("Could not save neutron route snapshot")

def _copy_system(system: str | None) -> None:
    if system and _app_frame is not None:
        try:
            _app_frame.clipboard_clear()
            _app_frame.clipboard_append(system)
            _app_frame.update_idletasks()
        except tk.TclError:
            logger.exception("Could not copy route system")

def _copy_next_waypoint() -> None:
    _copy_system(_next_system())

def _copy_current_waypoint() -> None:
    # Copy the most recently reached route system, retained during a fuel detour.
    _copy_system(_current_system())

def _copy_clicked(getter) -> None:
    system = getter()
    _copy_system(system)
    if system:
        _set_status(f"Copied: {system}")

def _read_route_csv(path: str) -> list[str]:
    with open(path, encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        normalized = {re.sub(r"[^a-z0-9]", "", name.lower()): name
                      for name in (reader.fieldnames or []) if name}
        column = next((normalized[key] for key in ("systemname", "system", "starsystem", "waypoint")
                       if key in normalized), None)
        if column is None:
            raise ValueError("The CSV needs a System Name, System, StarSystem, or Waypoint column.")
        systems = [(row.get(column) or "").strip() for row in reader]
    systems = [system for system in systems if system]
    if not systems:
        raise ValueError("The route contains no system names.")
    return systems

def _find_system_index(current_system: str | None, systems: list[str], after: int) -> int:
    if current_system:
        for index in range(max(0, after + 1), len(systems)):
            if systems[index].casefold() == current_system.casefold():
                return index
    return after

def _set_route(systems: list[str], live_system: str | None, kind: str = "neutron",
               bodies: dict[str, list[dict[str, Any]]] | None = None) -> None:
    global _route_systems, _route_index, _pace_anchor, _route_kind, _route_bodies
    _route_kind, _route_bodies = kind, dict(bodies or {})
    _pace_anchor = None
    _pace_samples.clear()
    _route_systems = list(systems)
    matched = _find_system_index(live_system, systems, -1)
    _route_index = max(0, matched) if systems else -1
    _persist_route()
    _save()

def _load_route_dialog() -> None:
    path = filedialog.askopenfilename(title="Load Route", parent=_app_frame,
                                     filetypes=(("CSV route", "*.csv"), ("All files", "*.*")))
    if not path:
        return
    try:
        systems = _read_route_csv(path)
        _set_route(systems, _snapshot.get("location", {}).get("system_name"))
    except (OSError, UnicodeError, csv.Error, ValueError) as error:
        logger.exception("Could not load neutron route")
        messagebox.showerror("Load Route", str(error), parent=_app_frame)

def _cancel_route() -> None:
    global _route_systems, _route_index, _route_kind, _route_bodies
    if not _route_systems or not messagebox.askyesno(
            "Cancel Route", "Cancel the current route?", parent=_app_frame):
        return
    _route_systems = []
    _route_index = -1
    _route_kind, _route_bodies = "neutron", {}
    _save()
    try:
        _persist_route()
    except OSError as error:
        logger.exception("Could not save cancelled route")
        messagebox.showerror("Cancel Route", str(error), parent=_app_frame)

def _update_route_progress(current_system: str | None, on_jump: bool = False) -> bool:
    global _route_index
    if not current_system or not _route_systems:
        return False
    # Arrival at the retained waypoint refreshes the clipboard without moving
    # progress; ordinary events in that system leave the clipboard alone.
    if (_current_system() or "").casefold() == current_system.casefold():
        if on_jump:
            _copy_next_waypoint()
        return False
    index = _find_system_index(current_system, _route_systems, _route_index)
    if index <= _route_index:
        if not on_jump:
            return False
        # A jump can rejoin anywhere on the route, including an earlier stop.
        index = _find_system_index(current_system, _route_systems, -1)
        if index < 0:
            return False
    global _pace_anchor
    now = time.monotonic()
    if on_jump and index == _route_index+1 and _pace_anchor is not None:
        interval = now-_pace_anchor
        if 15 <= interval <= _idle_limit():      # longer gaps were idle time (a break), not travel
            _pace_samples.append(interval)
            del _pace_samples[:-8]
    elif index != _route_index+1:
        _pace_samples.clear()
    _pace_anchor = now if on_jump else None
    _route_index = index
    _sync_route_snapshot()
    _refresh_route_label()
    try:
        _persist_route()
    except OSError:
        logger.exception("Could not save neutron route progress")
    if _next_system():
        _copy_next_waypoint()
    return True

def _open_data_folder() -> None:
    try:
        os.startfile(DATA_DIR)  # type: ignore[attr-defined]
    except (AttributeError, OSError):
        logger.exception("Could not open data folder")
        _set_status(f"Folder: {DATA_DIR}")

def _widget_alive(widget) -> bool:
    try:
        return widget is not None and bool(widget.winfo_exists())
    except tk.TclError:
        return False


def _palette():
    """Normal, highlight and background colours. Never raises: EDMC may call
    drawing code before its theme palette exists, and a failure here would stop
    the whole panel from being created."""
    try:
        from theme import theme
        palette = getattr(theme, "current", None) or {}
    except Exception:
        palette = {}

    def label_colour(option, fallback):
        try:
            if _widget_alive(_title_label):
                return _title_label.cget(option) or fallback
        except tk.TclError:
            pass
        return fallback

    try:
        default_highlight = config.get_str("dark_highlight", default="#ff8000") or "#ff8000"
    except Exception:
        default_highlight = "#ff8000"
    normal = palette.get("foreground") or label_colour("foreground", "black")
    highlight = palette.get("highlight") or default_highlight
    background = palette.get("background") or label_colour("background", "white")
    return normal, highlight, background

def _theme_event(event=None):
    global _theme_pending
    if not _stopped and _app_frame is not None and _theme_pending is None:
        _theme_pending = _app_frame.after_idle(_apply_theme)

def prefs_changed(cmdr=None,is_beta=False):
    # EDMC calls this after Settings > OK (Appearance changes too). One idle lets its theme finish.
    _apply_prefs_page()
    _theme_event()

# --- Route position lamp -------------------------------------------------
# Added by Claude (route editions, 22 Oct 2026).
# Replaces the separate bottom line from 0.14.0 ("Route Loaded" / "Detour" /
# "On Route" / ETA). The state now sits at the end of the Jumps line as a small
# lamp: green On Route, red Off Route, green Arrived. Nothing is shown until
# EDMC has told us where the ship is.
#
# Neutron routes list only the neutron waypoints, so ordinary travel often
# passes through systems that are not on the list. Those count as On Route
# while the game's own plotted route ends at a waypoint still ahead. Off Route
# means you are away from the route and not plotted back onto it (for
# example a fuel stop).
LAMP_ON = "#33cc33"
LAMP_OFF = "#d93636"      # red (Jonathan, 23 Oct; was amber)
SEP = "  |  "
_plotted_destination: str | None = None   # casefolded end of the game's plotted route
_plot_seen = False
_in_hyperspace = False     # between StartJump (Hyperspace) and arrival
_route_ending = False      # NavRouteClear arrived mid-jump: the plotted route is finishing
_lamp = None
_position_frame = None
_position_label = None


def _note_plotted_route(entry: dict, state: dict) -> None:
    """Follow where the game's plotted route ends (NavRoute / NavRouteClear / FSDTarget)."""
    global _plotted_destination, _plot_seen, _in_hyperspace, _route_ending
    event = entry.get("event")
    route = None
    if event == "StartJump":
        _in_hyperspace = entry.get("JumpType") == "Hyperspace"
        return
    if event in ("FSDJump", "Location", "CarrierJump"):
        _in_hyperspace = False
        if _route_ending:
            _plotted_destination, _route_ending = None, False
        return
    if event == "NavRouteClear":
        # The game clears a route as its final jump starts. Keep the destination
        # until we arrive, so leaving a fuel stop for a waypoint stays On Route.
        _plot_seen = True
        if _in_hyperspace:
            _route_ending = True
        else:
            _plotted_destination = None
        return
    if event == "FSDTarget":
        # One jump left in the plotted route: the target is its destination.
        if entry.get("RemainingJumpsInRoute") == 1 and entry.get("Name"):
            _plotted_destination, _plot_seen = str(entry["Name"]).casefold(), True
        return
    if event == "NavRoute":
        _route_ending = False
        saved = state.get("NavRoute") if isinstance(state, dict) else None
        route = entry.get("Route") or (saved.get("Route") if isinstance(saved, dict) else None)
    elif not _plot_seen:
        saved = state.get("NavRoute") if isinstance(state, dict) else None
        if not isinstance(saved, dict):
            return
        route = saved.get("Route") or []          # EDMC's copy of NavRoute.json at startup
    else:
        return
    if isinstance(route, list):
        _plot_seen = True
        last = route[-1] if route and isinstance(route[-1], dict) else {}
        _plotted_destination = str(last.get("StarSystem") or "").casefold() or None


def _route_position() -> str | None:
    """'arrived', 'on', 'off', or None when there is nothing to show yet."""
    if not _route_systems:
        return None
    if _route_index >= len(_route_systems) - 1:
        return "arrived"
    physical = str(_snapshot.get("location", {}).get("system_name") or "").casefold()
    if not physical:
        return None
    ahead = [name.casefold() for name in _route_systems[max(_route_index, 0):]]
    if physical in ahead:
        return "on"
    if _plotted_destination and _plotted_destination in ahead:
        return "on"
    return "off"


def _default_pace() -> float:
    """Settings page: minutes per jump to assume until your own pace is learned."""
    try:
        return min(60.0, max(0.25, float(_settings.get("eta_minutes_per_jump", 2.0))))
    except (TypeError, ValueError):
        return 2.0


def _idle_limit() -> float:
    """Seconds between waypoints above which the gap counts as idle (3x the default, at least 6 min)."""
    return max(360.0, _default_pace() * 60 * 3)


def _eta_text() -> str:
    """Average waypoint-to-waypoint time so far x waypoints left (from 0.14.0)."""
    left = _jump_counts()[1]
    if left <= 0:
        return ""
    if _pace_samples:
        seconds = sum(_pace_samples) / len(_pace_samples)
    else:
        seconds = _default_pace() * 60       # until your own pace is learned
    minutes = max(1, round(seconds * left / 60))
    return f"~{minutes} min" if minutes < 60 else f"~{minutes // 60}h {minutes % 60:02d}m"


class _Lamp(tk.Canvas):
    """A small filled circle sized to the text beside it."""

    def __init__(self, parent, reference) -> None:
        super().__init__(parent, width=10, height=10, highlightthickness=0, bd=0)
        self._reference = reference
        self._colour = LAMP_ON
        self.bind("<Map>", self.redraw)

    def set_colour(self, colour: str) -> None:
        self._colour = colour
        self.redraw()

    def redraw(self, _event=None) -> None:
        try:
            line = int(tkfont.Font(font=self._reference.cget("font")).metrics("linespace"))
        except (tk.TclError, ValueError):
            line = 16
        size = max(8, round(line * 0.55))
        if int(self.cget("width")) != size + 2:
            tk.Canvas.configure(self, width=size + 2, height=size + 2)
        self.delete("all")
        self.create_oval(1, 1, size + 1, size + 1, fill=self._colour, outline=self._colour)


def _refresh_position() -> None:
    if not _widget_alive(_position_frame):
        return
    position = _route_position()
    _refresh_route_bar(position)
    if position is None:
        _position_frame.pack_forget()
        return
    word = {"arrived": "Arrived", "on": "On Route", "off": "Off Route"}[position]
    eta = _eta_text() if position == "on" else ""
    _position_label.configure(text=word + (SEP + eta if eta else ""))
    on_colour, off_colour = _route_colours()
    _lamp.set_colour(off_colour if position == "off" else on_colour)
    if _route_bar_on():
        # The progress bar shows On Route / Off Route / Arrived; the Jumps line keeps only the ETA.
        _lamp.pack_forget()
        _position_label.configure(text=eta)
        if not eta:
            _position_frame.pack_forget()
            return
    elif not _lamp.winfo_manager():
        _lamp.pack(side=tk.LEFT, padx=(0, 4), before=_position_label)
    if not _position_frame.winfo_manager():
        _position_frame.pack(side=tk.LEFT)


def _build_position(progress) -> None:
    """The lamp group at the end of the Jumps line: '  |  (lamp) On Route  |  ~12 min'."""
    global _position_frame, _position_label, _lamp
    _position_frame = tk.Frame(progress)
    tk.Label(_position_frame, text=SEP, padx=0, bd=0).pack(side=tk.LEFT)
    _position_label = tk.Label(_position_frame, padx=0, bd=0)
    _lamp = _Lamp(_position_frame, _position_label)
    _lamp.pack(side=tk.LEFT, padx=(0, 4))
    _position_label.pack(side=tk.LEFT)

def _read_journal_json(name: str) -> dict[str, Any] | None:
    """Read one of the game's small JSON files (NavRoute.json, Cargo.json...).
    The game rewrites them often, so retry briefly if one is caught mid-write."""
    folder = _journal_dir()
    if not folder:
        return None
    path = os.path.join(folder, name)
    for _ in range(3):
        try:
            with open(path, encoding="utf-8") as stream:
                data = json.load(stream)
            return data if isinstance(data, dict) else None
        except FileNotFoundError:
            return None
        except (OSError, ValueError):
            time.sleep(0.05)
    return None

def _cargo_count() -> int:
    data = _read_journal_json("Cargo.json")
    if not data or data.get("Vessel", "Ship") != "Ship":
        return 0
    try:
        return int(data.get("Count") or 0)
    except (TypeError, ValueError):
        return 0

def _read_latest_loadout() -> dict[str, Any] | None:
    """The game writes a Loadout record whenever you board, switch or outfit a ship
    (not when you supercharge). Read the newest one from the newest journal files."""
    best = None
    folder = _journal_dir()
    if folder:
        try:
            files = sorted((os.path.join(folder, name) for name in os.listdir(folder)
                            if name.startswith("Journal") and name.endswith(".log")),
                           key=os.path.getmtime, reverse=True)[:5]
        except OSError:
            files = []
        for path in files:
            found = None
            try:
                with open(path, encoding="utf-8", errors="replace") as stream:
                    for line in stream:
                        if "Loadout" not in line:
                            continue
                        try:
                            record = json.loads(line)
                        except ValueError:
                            continue
                        if record.get("event") == "Loadout":
                            found = record
            except OSError:
                continue
            if found:
                best = found
                break
    cached = _last_loadout
    if cached and (best is None or str(cached.get("timestamp", "")) > str(best.get("timestamp", ""))):
        best = cached
    return best

def _ship_model_name(ship: str) -> str:
    key = ship.lower()
    try:
        from edmc_data import ship_name_map
        if key in ship_name_map:
            return ship_name_map[key]
    except Exception:
        pass
    if key in _RECENT_SHIPS:
        return _RECENT_SHIPS[key]
    # Brand-new ships: the game's own shipyard list has their display names
    # (Shipyard.json is written whenever you open a shipyard).
    shipyard = _read_journal_json("Shipyard.json") or {}
    for entry in shipyard.get("PriceList") or []:
        if isinstance(entry, dict) and str(entry.get("ShipType", "")).lower() == key \
                and entry.get("ShipType_Localised"):
            return str(entry["ShipType_Localised"])
    return ship.replace("_", " ").title()

def _ship_profile() -> dict[str, Any]:
    """Jump range and supercharge multiplier for the ship you are flying right now."""
    loadout = _read_latest_loadout()
    if not loadout:
        return {"ok": False, "range": 0.0, "multiplier": 4,
                "label": "No ship data found in your game journal yet."}
    fsd = next((str(module.get("Item", "")) for module in loadout.get("Modules", [])
                if module.get("Slot") == "FrameShiftDrive"), "")
    multiplier = 6 if "mkii" in fsd.lower() else 4        # SCO Mk II drive: x6, any other: x4
    try:
        jump_range = float(loadout.get("MaxJumpRange") or 0)
    except (TypeError, ValueError):
        jump_range = 0.0
    model = _ship_model_name(str(loadout.get("Ship", "")))
    name = str(loadout.get("ShipName") or "").strip()
    label = f"{name} ({model})" if name else model
    ok = 0 < jump_range <= MAX_SANE_RANGE
    planning, note = _planning_range(loadout, jump_range) if ok else (jump_range, "")
    logger.info("Plot New Route ship check: %s, FSD %s, game range %.2f, planning range %.2f (%s), x%d",
                label, fsd, jump_range, planning, note or "game figure", multiplier)
    return {"ok": ok, "range": planning, "best_range": jump_range, "range_note": note,
            "multiplier": multiplier, "label": label, "fsd": fsd}

def _spansh_request(url: str, data: dict[str, Any] | None = None, as_json: bool = False) -> Any:
    """GET (data=None) or POST a Spansh API call and return the JSON reply.
    Uses requests (bundled with EDMC, with its own certificate store) when available;
    Python's urllib inside a packaged app often cannot verify https certificates."""
    headers = {"User-Agent": f"{TITLE}/{VERSION} (EDMC plugin)", "Accept": "application/json"}
    try:
        import requests
    except ImportError:
        requests = None
    if requests is not None:
        try:
            if data is None:
                reply = requests.get(url, headers=headers, timeout=SPANSH_TIMEOUT)
            else:
                reply = (requests.post(url, json=data, headers=headers, timeout=SPANSH_TIMEOUT) if as_json
                         else requests.post(url, data=data, headers=headers, timeout=SPANSH_TIMEOUT))
        except requests.exceptions.RequestException as error:
            logger.warning("Spansh request to %s failed: %r", url, error)
            raise RuntimeError(f"Could not reach Spansh ({type(error).__name__}) - see the EDMC log.") from error
        if reply.status_code >= 400:
            try:
                detail = reply.json().get("error")
            except Exception:
                detail = None
            logger.warning("Spansh replied HTTP %s to %s: %s", reply.status_code, url, reply.text[:300])
            raise RuntimeError(str(detail) if detail else f"Spansh returned an error (HTTP {reply.status_code}).")
        try:
            return reply.json()
        except ValueError as error:
            logger.warning("Spansh reply from %s was not JSON: %s", url, reply.text[:300])
            raise RuntimeError("Spansh sent a reply the plugin could not read.") from error

    # Fallback without requests: urllib, with certifi's certificates if available.
    context = None
    try:
        import ssl
        import certifi
        context = ssl.create_default_context(cafile=certifi.where())
    except Exception:
        pass
    if data is not None and as_json:
        body = json.dumps(data).encode("utf-8")
        headers["Content-Type"] = "application/json"
    else:
        body = urllib.parse.urlencode(data).encode("utf-8") if data is not None else None
    request = urllib.request.Request(url, data=body, headers=headers)
    try:
        with urllib.request.urlopen(request, timeout=SPANSH_TIMEOUT, context=context) as response:
            return json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as error:
        try:
            detail = json.loads(error.read().decode("utf-8")).get("error")
        except Exception:
            detail = None
        logger.warning("Spansh replied HTTP %s to %s", error.code, url)
        raise RuntimeError(str(detail) if detail else f"Spansh returned an error (HTTP {error.code}).") from error
    except (urllib.error.URLError, TimeoutError, OSError) as error:
        logger.warning("Spansh request to %s failed: %r", url, error)
        raise RuntimeError(f"Could not reach Spansh ({type(getattr(error, 'reason', error)).__name__})"
                           " - see the EDMC log.") from error
    except ValueError as error:
        raise RuntimeError("Spansh sent a reply the plugin could not read.") from error

def _spansh_names(text: str) -> list[str]:
    """System name suggestions for what has been typed so far (Spansh's prefix lookup)."""
    reply = _spansh_request(SPANSH_NAMES_URL + "?" + urllib.parse.urlencode({"q": text}))
    values = reply.get("min_max", reply.get("values", [])) if isinstance(reply, dict) else reply
    names = []
    for value in values or []:
        name = value.get("name") if isinstance(value, dict) else value
        if isinstance(name, str) and name not in names:
            names.append(name)
    return names[:8]

def _spansh_plot(start: str, end: str, jump_range: float, efficiency: int, multiplier: int,
                 cancelled) -> list[tuple[str, int]]:
    """Ask Spansh's neutron plotter for a route; returns [(system, jumps), ...]."""
    params = {"from": start, "to": end, "range": f"{jump_range:.2f}",
              "efficiency": efficiency, "supercharge_multiplier": multiplier}
    logger.info("Plot New Route: asking Spansh %s", params)
    reply = _spansh_request(SPANSH_ROUTE_URL, params)
    job = reply.get("job") if isinstance(reply, dict) else None
    if not job:
        error = reply.get("error") if isinstance(reply, dict) else None
        raise RuntimeError(str(error) if error else "Spansh did not accept the request.")
    deadline = time.monotonic() + SPANSH_MAX_WAIT
    while True:
        if cancelled():
            raise _PlotCancelled()
        result = _spansh_request(SPANSH_RESULTS_URL + urllib.parse.quote(str(job)))
        if isinstance(result, dict):
            if result.get("error"):
                raise RuntimeError(str(result["error"]))
            body = result.get("result")
            jumps = body.get("system_jumps") if isinstance(body, dict) else None
            if isinstance(jumps, list):
                route = [(str(step["system"]), int(step.get("jumps") or 0))
                         for step in jumps if isinstance(step, dict) and step.get("system")]
                if len(route) < 2:
                    raise RuntimeError("Spansh returned an empty route.")
                logger.info("Plot New Route: Spansh returned %d waypoints", len(route))
                return route
        if time.monotonic() > deadline:
            raise RuntimeError("Spansh is still calculating - try again in a moment.")
        time.sleep(1.5)

# ---------------------------------------------------------------------------
# Uncharted space: when Spansh doesn't know your system, bridge to one it does.
# The game always writes your exact coordinates (StarPos) to the journal, so we
# ask Spansh for known neutron stars near them and route from the best one.
# ---------------------------------------------------------------------------
SPANSH_BODIES_URL = "https://spansh.co.uk/api/bodies/search"
SPANSH_NEAREST_URL = "https://spansh.co.uk/api/nearest"
SPANSH_SEARCH_URL = "https://spansh.co.uk/api/search/systems"
BRIDGE_CANDIDATES = 12       # nearest known neutrons to compare
BRIDGE_MIN_REACH = 500.0     # ly; always consider neutrons at least this far away
BRIDGE_REACH_JUMPS = 20      # ...or this many normal jumps, if that is further
_star_pos: tuple[str, tuple[float, float, float]] | None = None   # (system, StarPos)


def _note_star_pos(system: str | None, entry: dict[str, Any], state: dict[str, Any]) -> None:
    """Remember the coordinates of the system you are in (works in unexplored space)."""
    global _star_pos
    if entry.get("event") in ("Location", "FSDJump", "CarrierJump") and entry.get("StarPos"):
        name, position = entry.get("StarSystem") or system, entry.get("StarPos")
    else:
        name, position = system or state.get("SystemName"), state.get("StarPos")
    try:
        x, y, z = (float(value) for value in position)
    except (TypeError, ValueError):
        return
    if name:
        _star_pos = (str(name), (x, y, z))


def _journal_star_pos(name: str) -> tuple[float, float, float] | None:
    """Coordinates of a system you have been to, from the newest journal files."""
    folder = _journal_dir()
    if not folder:
        return None
    try:
        files = sorted((os.path.join(folder, item) for item in os.listdir(folder)
                        if item.startswith("Journal") and item.endswith(".log")),
                       key=os.path.getmtime, reverse=True)[:3]
    except OSError:
        return None
    for path in files:
        found = None
        try:
            with open(path, encoding="utf-8", errors="replace") as stream:
                for line in stream:
                    if '"StarPos"' not in line:
                        continue
                    try:
                        record = json.loads(line)
                    except ValueError:
                        continue
                    if str(record.get("StarSystem", "")).casefold() == name.casefold():
                        found = record.get("StarPos")
        except OSError:
            continue
        if found:
            try:
                x, y, z = (float(value) for value in found)
                return (x, y, z)
            except (TypeError, ValueError):
                pass
    return None


def _start_coordinates(name: str) -> tuple[float, float, float] | None:
    if _star_pos is not None and _star_pos[0].casefold() == name.casefold():
        return _star_pos[1]
    return _journal_star_pos(name)


def _unknown_start(error: Exception) -> bool:
    return "could not find starting system" in str(error).casefold()


def _spansh_coordinates(name: str) -> tuple[float, float, float] | None:
    """Coordinates of a system Spansh knows (exact name match), or None."""
    reply = _spansh_request(SPANSH_SEARCH_URL + "?" + urllib.parse.urlencode({"q": name}))
    for item in (reply.get("results") if isinstance(reply, dict) else None) or []:
        if isinstance(item, dict) and str(item.get("name", "")).casefold() == name.casefold():
            try:
                return (float(item["x"]), float(item["y"]), float(item["z"]))
            except (KeyError, TypeError, ValueError):
                return None
    return None


def _find_bridge(position: tuple[float, float, float], target: str, jump_range: float,
                 multiplier: int) -> dict[str, Any]:
    """A known neutron near you (main star only, on the way to target), else the nearest known system."""
    x, y, z = position
    query = {"filters": {"subtype": {"value": ["Neutron Star"]}, "is_main_star": {"value": True}},
             "sort": [{"distance": {"direction": "asc"}}], "size": BRIDGE_CANDIDATES, "page": 0,
             "reference_coords": {"x": x, "y": y, "z": z}}
    reply = _spansh_request(SPANSH_BODIES_URL, query, as_json=True)
    reach = max(BRIDGE_MIN_REACH, jump_range * BRIDGE_REACH_JUMPS)
    candidates, seen = [], set()
    for item in (reply.get("results") if isinstance(reply, dict) else None) or []:
        try:
            name, distance = str(item["system_name"]), float(item["distance"])
            coords = (float(item["system_x"]), float(item["system_y"]), float(item["system_z"]))
        except (KeyError, TypeError, ValueError):
            continue
        if distance <= reach and name.casefold() not in seen:
            seen.add(name.casefold())
            candidates.append({"system": name, "distance": distance, "coords": coords, "neutron": True})
    if candidates:
        try:
            goal = _spansh_coordinates(target) if target else None
        except RuntimeError:
            goal = None

        def cost(candidate: dict[str, Any]) -> float:
            # normal jumps to reach it, plus boosted jumps from it to the destination
            onward = math.dist(candidate["coords"], goal) / (jump_range * multiplier) if goal else 0.0
            return candidate["distance"] / jump_range + onward
        best = min(candidates, key=cost)
        logger.info("Plot New Route: bridge neutron %s at %.1f ly (of %d candidates, goal %s)",
                    best["system"], best["distance"], len(candidates), "known" if goal else "unknown")
        return best
    reply = _spansh_request(SPANSH_NEAREST_URL + "?" + urllib.parse.urlencode({"x": x, "y": y, "z": z}))
    system = reply.get("system") if isinstance(reply, dict) else None
    if isinstance(system, dict) and system.get("name"):
        logger.info("Plot New Route: no known neutron nearby; bridging via %s", system["name"])
        return {"system": str(system["name"]), "distance": float(system.get("distance") or 0),
                "neutron": False}
    raise RuntimeError("Spansh doesn't know any systems near you yet.")


def _plot_with_bridge(origin: str, target: str, jump_range: float, efficiency: int, multiplier: int,
                      cancelled) -> tuple[list[tuple[str, int]], dict[str, Any] | None]:
    """Plot normally; if Spansh doesn't know the start, plot from a nearby known system instead."""
    try:
        return _spansh_plot(origin, target, jump_range, efficiency, multiplier, cancelled), None
    except RuntimeError as error:
        if not _unknown_start(error):
            raise
    position = _start_coordinates(origin)
    if position is None:
        raise RuntimeError(f"Spansh doesn't know {origin} yet. A bridge route needs your"
                           " current system as the Start System.")
    logger.info("Plot New Route: %s is uncharted for Spansh; looking for a bridge near %s", origin, position)
    bridge = _find_bridge(position, target, jump_range, multiplier)
    if cancelled():
        raise _PlotCancelled()
    route = _spansh_plot(bridge["system"], target, jump_range, efficiency, multiplier, cancelled)
    first_leg = max(1, math.ceil(bridge["distance"] / jump_range))
    return [(origin, 0), (route[0][0], first_leg)] + route[1:], bridge


def _bridge_text(bridge: dict[str, Any], kind: str = "neutron") -> str:
    if kind == "galaxy":
        return (f"Uncharted space, Commander. Spansh doesn't know this system yet.\n"
                f"Your galaxy route starts from {bridge['system']} ({bridge['distance']:.0f} ly).")
    if kind == "exo":
        return (f"Uncharted space, Commander. Spansh doesn't know this system yet.\n"
                f"Your Exomastery route starts from {bridge['system']} ({bridge['distance']:.0f} ly).")
    if kind == "riches":
        return (f"Uncharted space, Commander. Spansh doesn't know this system yet.\n"
                f"Your Road to Riches starts from {bridge['system']} ({bridge['distance']:.0f} ly).")
    if bridge["neutron"]:
        return (f"Uncharted space, Commander. Spansh doesn't know this system yet.\n"
                f"Bridging via {bridge['system']} ({bridge['distance']:.0f} ly) onto the Neutron Highway.")
    return (f"Uncharted space, Commander. No known neutron nearby, so the route starts from\n"
            f"{bridge['system']} ({bridge['distance']:.0f} ly), the nearest system Spansh knows.")


# ---------------------------------------------------------------------------
# Road to Riches (Spansh): systems with valuable bodies to scan, near you or on
# the way to a destination. The panel's Scan line lists the bodies at each stop.
# ---------------------------------------------------------------------------
SPANSH_RICHES_URL = "https://spansh.co.uk/api/riches/route"
ROUTE_TYPES = ("Neutron Highway", "Road to Riches", "Exomastery", "Galaxy Plotter")
ROUTE_KINDS = ("neutron", "riches", "exo", "galaxy")
SCAN_KINDS = ("riches", "exo")      # route types with bodies to scan (they share the four settings)
RICHES_FIELDS = (("riches_radius", "Search Radius (ly)"), ("riches_max_systems", "Max Systems"),
                 ("riches_min_value", "Min Value (cr)"), ("riches_max_ls", "Max Distance (ls)"))
RICHES_ENOUGH = 5             # fewer systems than this: widen the search by itself
RICHES_MAX_RADIUS = 200       # ly; the widest automatic search
_riches_radius_used = 0.0     # radius of the last Road to Riches search (after widening)
SCAN_SHOWN = 5                # bodies listed on the Scan line before "+N more"
BODY_SHORT = {"Earth-like world": "ELW", "Water world": "WW", "Ammonia world": "AW",
              "High metal content world": "HMC", "Metal-rich body": "Metal-rich",
              "Rocky body": "Rocky", "Rocky Ice world": "Rocky ice", "Icy body": "Icy"}
_route_kind = "neutron"       # "neutron" or "riches"
_route_bodies: dict[str, list[dict[str, Any]]] = {}   # casefolded system -> bodies to scan
_scan_label = None


def _credits(value: float) -> str:
    if value >= 1_000_000_000:
        return f"{value / 1_000_000_000:.1f}B"
    if value >= 1_000_000:
        return f"{value / 1_000_000:.1f}M"
    return f"{value / 1000:.0f}k"


def _has_dss() -> bool:
    """Body values include mapping when a Detailed Surface Scanner is fitted (assume yes if unknown)."""
    loadout = _read_latest_loadout()
    if not loadout:
        return True
    return any("detailedsurfacescanner" in str(module.get("Item", "")).lower()
               for module in loadout.get("Modules", []) if isinstance(module, dict))


def _spansh_result(job: Any, cancelled) -> Any:
    """Wait for a queued Spansh job and return its result."""
    deadline = time.monotonic() + SPANSH_MAX_WAIT
    while True:
        if cancelled():
            raise _PlotCancelled()
        reply = _spansh_request(SPANSH_RESULTS_URL + urllib.parse.quote(str(job)))
        if isinstance(reply, dict):
            if reply.get("error"):
                raise RuntimeError(str(reply["error"]))
            if reply.get("status") == "ok" and reply.get("result") is not None:
                return reply["result"]
        if time.monotonic() > deadline:
            raise RuntimeError("Spansh is still calculating - try again in a moment.")
        time.sleep(1.5)


def _spansh_riches(start: str, end: str, jump_range: float, options: dict[str, float], mapping: bool,
                   cancelled) -> tuple[list[tuple[str, int]], dict[str, list[dict[str, Any]]]]:
    """Ask Spansh's Road to Riches for systems worth scanning; returns (route, bodies)."""
    params = {"from": start, "range": f"{jump_range:.2f}",
              "radius": int(options["riches_radius"]), "max_results": int(options["riches_max_systems"]),
              "max_distance": int(options["riches_max_ls"]), "min_value": int(options["riches_min_value"]),
              "use_mapping_value": 1 if mapping else 0, "loop": 0}
    if end:
        params["to"] = end
    logger.info("Plot New Route: asking Spansh Road to Riches %s", params)
    reply = _spansh_request(SPANSH_RICHES_URL, params)
    job = reply.get("job") if isinstance(reply, dict) else None
    if not job:
        error = reply.get("error") if isinstance(reply, dict) else None
        raise RuntimeError(str(error) if error else "Spansh did not accept the request.")
    result = _spansh_result(job, cancelled)
    route, bodies = [], {}
    for stop in result if isinstance(result, list) else []:
        if not isinstance(stop, dict) or not stop.get("name"):
            continue
        name = str(stop["name"])
        route.append((name, int(stop.get("jumps") or 0)))
        found = []
        for body in stop.get("bodies") or []:
            if not isinstance(body, dict):
                continue
            full = str(body.get("name") or "")
            short = full[len(name):].strip() if full.casefold().startswith(name.casefold()) else full
            kind = BODY_SHORT.get(str(body.get("subtype") or ""), str(body.get("subtype") or "Body"))
            if body.get("is_terraformable"):
                kind += " (T)"
            value = body.get("estimated_mapping_value" if mapping else "estimated_scan_value") or 0
            try:
                found.append({"name": short or full, "type": kind, "value": int(value),
                              "ls": int(float(body.get("distance_to_arrival") or 0))})
            except (TypeError, ValueError):
                continue
        if found:
            bodies[name.casefold()] = sorted(found, key=lambda item: item["ls"])
    if len(route) < 2 or not bodies:
        raise RuntimeError("Spansh found no systems that match - try a larger radius or a lower value.")
    logger.info("Plot New Route: Road to Riches returned %d systems, %d with bodies", len(route), len(bodies))
    return route, bodies


def _riches_search(start: str, end: str, jump_range: float, options: dict[str, float], mapping: bool,
                   cancelled, fetch=None) -> tuple[list[tuple[str, int]], dict[str, list[dict[str, Any]]]]:
    """Road to Riches that widens its own search radius (up to 200 ly) when too little comes back,
    as in sparsely explored space, so nobody has to guess a radius."""
    global _riches_radius_used
    wanted = min(RICHES_ENOUGH, int(options["riches_max_systems"]))
    radius, best = float(options["riches_radius"]), None
    while True:
        try:
            route, bodies = (fetch or _spansh_riches)(start, end, jump_range, dict(options, riches_radius=radius),
                                           mapping, cancelled)
            best = (route, bodies, radius)
        except RuntimeError as error:
            if _unknown_start(error) or "found no systems" not in str(error):
                raise
        if (best is not None and len(best[1]) >= wanted) or radius >= RICHES_MAX_RADIUS:
            break
        radius = min(RICHES_MAX_RADIUS, radius * 2)
        logger.info("Plot New Route: few riches found; widening the search to %.0f ly", radius)
    if best is None:
        raise RuntimeError("Spansh found no systems that match, even within 200 ly - try a lower value.")
    _riches_radius_used = best[2]
    return best[0], best[1]


SPANSH_EXO_URL = "https://spansh.co.uk/api/exobiology/route"


def _spansh_exo(start: str, end: str, jump_range: float, options: dict[str, float], _mapping: bool,
                cancelled) -> tuple[list[tuple[str, int]], dict[str, list[dict[str, Any]]]]:
    """Spansh's Exomastery: bodies with valuable biology. Thargoid systems are always avoided."""
    params = {"from": start, "range": f"{jump_range:.2f}",
              "radius": int(options["riches_radius"]), "max_results": int(options["riches_max_systems"]),
              "max_distance": int(options["riches_max_ls"]), "min_value": int(options["riches_min_value"]),
              "avoid_thargoids": 1, "loop": 0}
    if end:
        params["to"] = end
    logger.info("Plot New Route: asking Spansh Exomastery %s", params)
    reply = _spansh_request(SPANSH_EXO_URL, params)
    job = reply.get("job") if isinstance(reply, dict) else None
    if not job:
        error = reply.get("error") if isinstance(reply, dict) else None
        raise RuntimeError(str(error) if error else "Spansh did not accept the request.")
    result = _spansh_result(job, cancelled)
    route, bodies = [], {}
    for stop in result if isinstance(result, list) else []:
        if not isinstance(stop, dict) or not stop.get("name"):
            continue
        name = str(stop["name"])
        route.append((name, int(stop.get("jumps") or 0)))
        found = []
        for body in stop.get("bodies") or []:
            if not isinstance(body, dict):
                continue
            full = str(body.get("name") or "")
            short = full[len(name):].strip() if full.casefold().startswith(name.casefold()) else full
            species = []
            for landmark in body.get("landmarks") or []:
                if isinstance(landmark, dict):
                    try:
                        species.append((str(landmark.get("subtype") or landmark.get("type") or "Species"),
                                        int(landmark.get("value") or 0)))
                    except (TypeError, ValueError):
                        continue
            if species:
                species.sort(key=lambda item: -item[1])
                found.append({"name": short or full, "type": "", "value": sum(value for _, value in species),
                              "ls": int(float(body.get("distance_to_arrival") or 0)), "species": species})
        if found:
            bodies[name.casefold()] = sorted(found, key=lambda item: item["ls"])
    if len(route) < 2 or not bodies:
        raise RuntimeError("Spansh found no systems that match - try a larger radius or a lower value.")
    logger.info("Plot New Route: Exomastery returned %d systems, %d with biology", len(route), len(bodies))
    return route, bodies


def _plot_riches(origin: str, end: str, jump_range: float, multiplier: int, options: dict[str, float],
                 cancelled, fetch=None) -> tuple[list[tuple[str, int]], dict[str, Any] | None, dict[str, list[dict[str, Any]]]]:
    """Road to Riches, with the uncharted-space bridge when Spansh doesn't know the start."""
    mapping = _has_dss()
    try:
        route, bodies = _riches_search(origin, end, jump_range, options, mapping, cancelled, fetch)
        return route, None, bodies
    except RuntimeError as error:
        if not _unknown_start(error):
            raise
    position = _start_coordinates(origin)
    if position is None:
        raise RuntimeError(f"Spansh doesn't know {origin} yet. A bridge route needs your"
                           " current system as the Start System.")
    bridge = _find_bridge(position, end, jump_range, multiplier)
    if cancelled():
        raise _PlotCancelled()
    route, bodies = _riches_search(bridge["system"], end, jump_range, options, mapping, cancelled, fetch)
    first_leg = max(1, math.ceil(bridge["distance"] / jump_range))
    return [(origin, 0), (route[0][0], first_leg)] + route[1:], bridge, bodies


def _count(number: int, one: str, many: str | None = None) -> str:
    return f"{number} {one if number == 1 else (many or one + 's')}"


def _route_summary(route: list[tuple[str, int]], kind: str, bodies: dict[str, list[dict[str, Any]]]) -> str:
    total = sum(jumps for _, jumps in route)
    if kind == "galaxy":
        refuels = sum(1 for item in bodies.values() if isinstance(item, dict) and item.get("refuel"))
        boosts = sum(1 for item in bodies.values() if isinstance(item, dict) and item.get("neutron"))
        injects = sum(1 for item in bodies.values() if isinstance(item, dict) and item.get("inject"))
        line = (f"{len(route)} waypoints, {total} jumps: {boosts} neutron boost{'s' if boosts != 1 else ''}, "
                f"{refuels} refuel stop{'s' if refuels != 1 else ''}"
                + (f", {injects} FSD injection{'s' if injects != 1 else ''}." if injects else "."))
        have = _injections_available()[0]
        if injects and 0 <= have < injects:
            line += f"\nNot enough materials: the route needs {injects} premium injections, you can make {have}."
        if _galaxy_last_ship.get("check", 0) > 0.5:
            line += (f"\nNote: the plugin's jump range for your ship ({_galaxy_last_ship['range']:.2f} ly)"
                     f" differs from the game's ({_galaxy_last_ship['game_range']:.2f} ly).")
        if not _galaxy_last_ship.get("scoop", True):
            line += "\nNo fuel scoop fitted: Spansh plans refuels at scoopable stars."
        return line
    if kind == "exo":
        species = sum(len(item.get("species", [])) for items in bodies.values() for item in items)
        planets = sum(len(items) for items in bodies.values())
        value = sum(item["value"] for items in bodies.values() for item in items)
        return (f"{_count(len(bodies), 'system')}, {_count(planets, 'body', 'bodies')}, {species} species to scan, "
                f"about {total} jumps.\n"
                f"Estimated value: {_credits(value)} cr (before any first-footfall bonus)"
                + (f"\nSearch widened to {_riches_radius_used:.0f} ly to find enough systems."
                   if _riches_radius_used > float(_settings.get("riches_radius", 25)) else ""))
    if kind != "riches":
        return f"{len(route)} waypoints, about {total} jumps."
    count = sum(len(items) for items in bodies.values())
    value = sum(item["value"] for items in bodies.values() for item in items)
    return (f"{_count(len(bodies), 'system')}, {_count(count, 'body', 'bodies')} to scan, about {total} jumps.\n"
            f"Estimated value: {_credits(value)} cr" + ("" if _has_dss() else " (scan only, no DSS fitted)")
            + (f"\nSearch widened to {_riches_radius_used:.0f} ly to find enough systems."
               if _riches_radius_used > float(_settings.get("riches_radius", 25)) else ""))


def _waypoint_word() -> str:
    return {"riches": "Stop", "exo": "Stop", "galaxy": "Waypoint"}.get(_route_kind, "Neutron")


def _build_scan_label(row: int) -> None:
    global _scan_label
    _scan_label = tk.Label(_app_frame, anchor=tk.W, justify=tk.LEFT, wraplength=320)
    _scan_label.grid(row=row, column=0, sticky=tk.W)
    _scan_label.grid_remove()


def _refresh_scan() -> None:
    """Road to Riches: list the bodies at this stop (when you are there), else at the next one."""
    if not _widget_alive(_scan_label):
        return
    text = ""
    if _route_kind == "galaxy" and _route_systems and not _settings.get("collapsed"):
        physical = str(_snapshot.get("location", {}).get("system_name") or "").casefold()
        current, following = _current_system(), _next_system()
        here = _route_bodies.get(current.casefold()) if current else None
        ahead = _route_bodies.get(following.casefold()) if following else None
        at_here = isinstance(here, dict) and physical == current.casefold()
        if at_here and here.get("refuel") and here.get("inject"):
            text = "Refuel and inject here: scoop, then synthesise a premium FSD injection before jumping."
        elif at_here and here.get("inject"):
            text = "Inject here: synthesise a premium FSD injection before your next jump."
        elif at_here and here.get("refuel"):
            text = "Refuel here: scoop before your next jump."
        elif isinstance(ahead, dict) and ahead.get("inject"):
            text = f"FSD injection next: synthesise one at {following} before jumping on."
        elif isinstance(ahead, dict) and ahead.get("refuel"):
            text = f"Refuel stop next: scoop at {following}."
    if _route_kind in SCAN_KINDS and _route_systems and not _settings.get("collapsed"):
        physical = str(_snapshot.get("location", {}).get("system_name") or "").casefold()
        current, following = _current_system(), _next_system()
        if current and physical == current.casefold() and _route_bodies.get(physical):
            word, items = "Scan here", _route_bodies[physical]
        elif following and _route_bodies.get(following.casefold()):
            word, items = "Next scan", _route_bodies[following.casefold()]
        else:
            items = []
        if items and _route_kind == "exo":
            # Exomastery: the nearest body with biology, then its species (most valuable first).
            body = items[0]
            species = body.get("species") or []
            shown = ", ".join(f"{name} {_credits(value)}" for name, value in species[:3])
            more = len(species) - 3 + sum(len(item.get("species") or []) for item in items[1:])
            text = f"{word}: {body['name']}: {shown}" + (f", +{more} more" if more > 0 else "")
        elif items:
            shown = ", ".join(f"{item['name']} {item['type']} {_credits(item['value'])}"
                              for item in items[:SCAN_SHOWN])
            more = f", +{len(items) - SCAN_SHOWN} more" if len(items) > SCAN_SHOWN else ""
            text = f"{word}: {shown}{more}"
    if text:
        _scan_label.configure(text=text)
        _scan_label.grid()
    else:
        _scan_label.grid_remove()


# ---------------------------------------------------------------------------
# Fuel warnings: the game writes your fuel after every jump and the star class
# of every jump in a plotted route, so the plugin can warn before fuel runs out.
# ---------------------------------------------------------------------------
SCOOPABLE = "KGBFOAM"
FUEL_MARGINS = {"relaxed": 1, "normal": 2, "cautious": 4}   # spare jumps of fuel wanted
FUEL_CHOICES = (("off", "Off"), ("relaxed", "Relaxed"), ("normal", "Normal"), ("cautious", "Cautious"))
_fuel_used: list[float] = []      # fuel used by recent jumps (t)
_next_star_class = ""             # from StartJump: the star you are jumping to
_arrival_star_class = ""          # the star you arrived at
_fuel_last_warning: tuple[str, str] | None = None


def _add_fuel_menu(menu: tk.Menu) -> None:
    sub = tk.Menu(menu, tearoff=0)
    choice = tk.StringVar(menu, value=str(_settings.get("fuel_safety", "normal")))
    menu._fuel_choice = choice            # keep the variable alive with the menu
    for value, label in FUEL_CHOICES:
        sub.add_radiobutton(label=label, value=value, variable=choice,
                            command=lambda chosen=value: _set_fuel_safety(chosen))
    menu.add_cascade(label="Fuel Warnings", menu=sub)


def _set_fuel_safety(value: str) -> None:
    _settings["fuel_safety"] = value
    _save_settings()
    _set_status("Fuel warnings off." if value == "off" else f"Fuel warnings: {value.title()}.")


def _note_fuel(entry: dict[str, Any]) -> None:
    global _next_star_class, _arrival_star_class
    event = entry.get("event")
    if event == "StartJump" and entry.get("JumpType") == "Hyperspace":
        _next_star_class = str(entry.get("StarClass") or "")
    elif event == "FSDJump":
        _arrival_star_class, _next_star_class = _next_star_class, ""
        try:
            used = float(entry.get("FuelUsed") or 0)
        except (TypeError, ValueError):
            used = 0.0
        if used > 0:
            _fuel_used.append(used)
            del _fuel_used[:-6]
        _fuel_check(str(entry.get("StarSystem") or ""), entry.get("FuelLevel"))
    elif event == "NavRoute":
        _fuel_check(str(_snapshot.get("location", {}).get("system_name") or ""), None)
    elif event in ("Location", "CarrierJump"):
        _arrival_star_class = ""
    if event == "JetConeBoost":
        _galaxy_state["supercharged"] = True
    elif event in ("FSDJump", "Location", "CarrierJump", "Died"):
        _galaxy_state["supercharged"] = False


def _fuel_warning(system: str, fuel: float | None, route: list[dict[str, Any]], margin: int) -> str:
    """The warning to show for this fuel level and plotted route ('' when all is well)."""
    if fuel is None or not _fuel_used:
        return ""
    per_jump = max(sum(_fuel_used[-4:]) / len(_fuel_used[-4:]), 0.01)
    jumps = int(fuel // per_jump)
    names = [str(item.get("StarSystem") or "") for item in route]
    folded = [name.casefold() for name in names]
    here = folded.index(system.casefold()) if system.casefold() in folded else -1
    ahead = route[here + 1:] if here >= 0 else []     # a route that doesn't include you is stale
    if not ahead and not _route_systems:
        return ""                       # nothing plotted and no route loaded
    loadout = _read_latest_loadout() or {}
    scoop = any("fuelscoop" in str(module.get("Item", "")).lower()
                for module in loadout.get("Modules", []) if isinstance(module, dict))
    left = f"about {jumps} jump{'s' if jumps != 1 else ''} of fuel"
    if not loadout:
        scoop = True                    # unknown ship: only warn about low fuel below
    if not scoop:
        if jumps <= margin or (ahead and jumps < len(ahead) + margin):
            return f"Fuel check: {left} and no fuel scoop fitted. Plan a refuelling stop."
        return ""
    next_scoop = next((index for index, item in enumerate(ahead, start=1)
                       if str(item.get("StarClass") or "")[:1] in SCOOPABLE and str(item.get("StarClass") or "")), None)
    if _arrival_star_class[:1] in SCOOPABLE and _arrival_star_class:
        gap = next_scoop or len(ahead)
        if jumps <= margin or jumps < gap + margin:
            where = (f"the next scoopable star is {gap} jump{'s' if gap != 1 else ''} away" if next_scoop
                     else "no scoopable star is left on this leg")
            return f"Fuel check: top up here ({_arrival_star_class} star). {left[0].upper() + left[1:]}, and {where}."
        return ""
    if next_scoop is None:
        if ahead and jumps < len(ahead) + margin:
            return f"Fuel check: {left} and no scoopable star on this leg. Re-plot via a scoopable star."
    elif jumps < next_scoop:
        return (f"Fuel check: {left}, but the next scoopable star ({names[here + next_scoop]})"
                f" is {next_scoop} jumps away. Re-plot via a closer scoopable star.")
    elif jumps < next_scoop + margin:
        return f"Fuel check: {left}. Top up at {names[here + next_scoop]} ({next_scoop} jumps ahead)."
    if jumps <= margin:
        return f"Fuel check: {left}. Top up at the next scoopable star."
    return ""


def _fuel_check(system: str, fuel_level: Any) -> None:
    global _fuel_last_warning
    margin = FUEL_MARGINS.get(str(_settings.get("fuel_safety", "normal")))
    if margin is None or not system:
        return
    fuel = None
    try:
        fuel = float(fuel_level) if fuel_level is not None else None
    except (TypeError, ValueError):
        fuel = None
    if fuel is None:
        status = _read_journal_json("Status.json") or {}
        try:
            fuel = float((status.get("Fuel") or {}).get("FuelMain"))
        except (TypeError, ValueError):
            fuel = None
    navroute = _read_journal_json("NavRoute.json") or {}
    route = [item for item in navroute.get("Route") or [] if isinstance(item, dict)]
    message = _fuel_warning(system, fuel, route, margin)
    if message and _fuel_last_warning != (system.casefold(), message):
        _fuel_last_warning = (system.casefold(), message)
        logger.info("%s", message)
        _set_status(message)


# ---------------------------------------------------------------------------
# Galaxy Plotter (Spansh's exact plotter): every jump, fuel-aware, using your
# ship's real FSD. The ship is read from the game's Loadout record; FSD stats
# come from coriolis-data (EDCD). The game data is (c) Frontier Developments plc.
# ---------------------------------------------------------------------------
SPANSH_GALAXY_URL = "https://spansh.co.uk/api/generic/route"
GALAXY_ALGORITHMS = (("Optimistic (fastest)", "optimistic"), ("Pessimistic", "pessimistic"),
                     ("Guided", "guided"), ("Fewest refuels", "fuel"), ("Fewest refuels and jumps", "fuel_jumps"))
GUARDIAN_BOOST = {1: 4.0, 2: 6.0, 3: 7.75, 4: 9.25, 5: 10.5}   # ly, by Guardian FSD Booster size
GALAXY_RESERVE_JUMPS = {"off": 0, "relaxed": 0, "normal": 1, "cautious": 2}   # fuel kept back, in max jumps
_galaxy_state: dict[str, Any] = {"supercharged": False}
_galaxy_last_ship: dict[str, Any] = {}
FSD_STATS = {   # symbol -> [(optimal mass, max fuel per jump, fuel multiplier, fuel power), ...]
    "int_hyperdrive_overcharge_size2_class1": [(60, 0.6, 0.008, 2.0)],
    "int_hyperdrive_overcharge_size2_class2": [(90, 0.9, 0.012, 2.0)],
    "int_hyperdrive_overcharge_size2_class3": [(90, 0.9, 0.012, 2.0)],
    "int_hyperdrive_overcharge_size2_class4": [(90, 0.9, 0.012, 2.0)],
    "int_hyperdrive_overcharge_size2_class5": [(100, 1, 0.013, 2.0)],
    "int_hyperdrive_overcharge_size3_class1": [(100, 1.2, 0.008, 2.15)],
    "int_hyperdrive_overcharge_size3_class2": [(150, 1.8, 0.012, 2.15)],
    "int_hyperdrive_overcharge_size3_class3": [(150, 1.8, 0.012, 2.15)],
    "int_hyperdrive_overcharge_size3_class4": [(150, 1.8, 0.012, 2.15)],
    "int_hyperdrive_overcharge_size3_class5": [(167, 1.9, 0.013, 2.15)],
    "int_hyperdrive_overcharge_size4_class1": [(350, 2, 0.008, 2.3)],
    "int_hyperdrive_overcharge_size4_class2": [(525, 3, 0.012, 2.3)],
    "int_hyperdrive_overcharge_size4_class3": [(525, 3, 0.012, 2.3)],
    "int_hyperdrive_overcharge_size4_class4": [(525, 3, 0.012, 2.3)],
    "int_hyperdrive_overcharge_size4_class5": [(585, 3.2, 0.013, 2.3)],
    "int_hyperdrive_overcharge_size5_class1": [(700, 3.3, 0.008, 2.45)],
    "int_hyperdrive_overcharge_size5_class2": [(1050, 5, 0.012, 2.45)],
    "int_hyperdrive_overcharge_size5_class3": [(1050, 5, 0.012, 2.45)],
    "int_hyperdrive_overcharge_size5_class4": [(1050, 5, 0.012, 2.45)],
    "int_hyperdrive_overcharge_size5_class5": [(1175, 5.2, 0.013, 2.45), (1175, 5.2, 0.012, 2.45)],
    "int_hyperdrive_overcharge_size6_class1": [(1200, 5.3, 0.008, 2.6)],
    "int_hyperdrive_overcharge_size6_class2": [(1800, 8, 0.012, 2.6)],
    "int_hyperdrive_overcharge_size6_class3": [(1800, 8, 0.012, 2.6)],
    "int_hyperdrive_overcharge_size6_class4": [(1800, 8, 0.012, 2.6)],
    "int_hyperdrive_overcharge_size6_class5": [(2000, 8.3, 0.013, 2.6)],
    "int_hyperdrive_overcharge_size7_class1": [(1800, 8.5, 0.008, 2.75)],
    "int_hyperdrive_overcharge_size7_class2": [(2700, 12.8, 0.012, 2.75)],
    "int_hyperdrive_overcharge_size7_class3": [(2700, 12.8, 0.012, 2.75)],
    "int_hyperdrive_overcharge_size7_class4": [(2700, 12.8, 0.012, 2.75)],
    "int_hyperdrive_overcharge_size7_class5": [(3000, 13.1, 0.013, 2.75)],
    "int_hyperdrive_overcharge_size8_class1": [(2800, 13.6, 0.008, 2.9)],
    "int_hyperdrive_overcharge_size8_class2": [(4200, 20.4, 0.012, 2.9)],
    "int_hyperdrive_overcharge_size8_class3": [(4200, 20.4, 0.012, 2.9)],
    "int_hyperdrive_overcharge_size8_class4": [(4200, 20.4, 0.012, 2.9)],
    "int_hyperdrive_overcharge_size8_class5": [(4670, 20.7, 0.013, 2.9)],
    "int_hyperdrive_overcharge_size8_class5_overchargebooster_mkii": [(4670, 6.8, 0.011, 2.5025)],
    "int_hyperdrive_size2_class1": [(48, 0.6, 0.011, 2)],
    "int_hyperdrive_size2_class2": [(54, 0.6, 0.01, 2)],
    "int_hyperdrive_size2_class3": [(60, 0.6, 0.008, 2)],
    "int_hyperdrive_size2_class4": [(75, 0.8, 0.01, 2)],
    "int_hyperdrive_size2_class5": [(90, 0.9, 0.012, 2)],
    "int_hyperdrive_size3_class1": [(80, 1.2, 0.011, 2.15)],
    "int_hyperdrive_size3_class2": [(90, 1.2, 0.01, 2.15)],
    "int_hyperdrive_size3_class3": [(100, 1.2, 0.008, 2.15)],
    "int_hyperdrive_size3_class4": [(125, 1.5, 0.01, 2.15)],
    "int_hyperdrive_size3_class5": [(150, 1.8, 0.012, 2.15)],
    "int_hyperdrive_size4_class1": [(280, 2, 0.011, 2.3)],
    "int_hyperdrive_size4_class2": [(315, 2, 0.01, 2.3)],
    "int_hyperdrive_size4_class3": [(350, 2, 0.008, 2.3)],
    "int_hyperdrive_size4_class4": [(437.5, 2.5, 0.01, 2.3)],
    "int_hyperdrive_size4_class5": [(525, 3, 0.012, 2.3)],
    "int_hyperdrive_size5_class1": [(560, 3.3, 0.011, 2.45)],
    "int_hyperdrive_size5_class2": [(630, 3.3, 0.01, 2.45)],
    "int_hyperdrive_size5_class3": [(700, 3.3, 0.008, 2.45)],
    "int_hyperdrive_size5_class4": [(875, 4.1, 0.01, 2.45)],
    "int_hyperdrive_size5_class5": [(1050, 5, 0.012, 2.45)],
    "int_hyperdrive_size6_class1": [(960, 5.3, 0.011, 2.6)],
    "int_hyperdrive_size6_class2": [(1080, 5.3, 0.01, 2.6)],
    "int_hyperdrive_size6_class3": [(1200, 5.3, 0.008, 2.6)],
    "int_hyperdrive_size6_class4": [(1500, 6.6, 0.01, 2.6)],
    "int_hyperdrive_size6_class5": [(1800, 8, 0.012, 2.6)],
    "int_hyperdrive_size7_class1": [(1440, 8.5, 0.011, 2.75)],
    "int_hyperdrive_size7_class2": [(1620, 8.5, 0.01, 2.75)],
    "int_hyperdrive_size7_class3": [(1800, 8.5, 0.008, 2.75)],
    "int_hyperdrive_size7_class4": [(2250, 10.6, 0.01, 2.75)],
    "int_hyperdrive_size7_class5": [(2700, 12.8, 0.012, 2.75)],
}


def _galaxy_ship(loadout: dict[str, Any] | None) -> dict[str, Any]:
    """The ship numbers Spansh's Galaxy Plotter needs, from the game's Loadout record.
    Checked against the game's own MaxJumpRange; engineered FSD values are used as recorded."""
    if not loadout:
        raise RuntimeError("Galaxy Plotter needs your ship's details. Board your ship, then try again.")
    modules = [module for module in loadout.get("Modules") or [] if isinstance(module, dict)]
    fsd = next((module for module in modules if str(module.get("Slot", "")).lower() == "frameshiftdrive"), None)
    item = str((fsd or {}).get("Item", "")).lower()
    variants = FSD_STATS.get(item)
    if not variants:
        raise RuntimeError(f"Galaxy Plotter doesn't know this FSD yet ({(fsd or {}).get('Item', 'none')}).\n"
                           "Neutron Highway still works with any FSD.")
    engineered = {}
    for modifier in ((fsd or {}).get("Engineering") or {}).get("Modifiers") or []:
        if isinstance(modifier, dict):
            try:
                engineered[str(modifier.get("Label", "")).lower()] = float(modifier.get("Value"))
            except (TypeError, ValueError):
                pass
    boost = 0.0
    for module in modules:
        found = re.match(r"int_guardianfsdbooster_size(\d)", str(module.get("Item", "")).lower())
        if found:
            boost = GUARDIAN_BOOST.get(int(found.group(1)), 0.0)
    capacity = loadout.get("FuelCapacity") or {}
    try:
        unladen = float(loadout.get("UnladenMass") or 0)
        tank, reserve = float(capacity.get("Main") or 0), float(capacity.get("Reserve") or 0)
        game_range = float(loadout.get("MaxJumpRange") or 0)
    except (TypeError, ValueError, AttributeError):
        unladen = tank = reserve = game_range = 0.0
    if unladen <= 0 or tank <= 0:
        raise RuntimeError("Galaxy Plotter could not read your ship's mass and fuel tank. Board your ship, then try again.")
    best = None
    for optmass, maxfuel, fuelmul, fuelpower in variants:      # some drives have two listed variants
        optmass = engineered.get("fsdoptimalmass", optmass)
        maxfuel = engineered.get("maxfuelperjump", maxfuel)
        reach = optmass / (unladen + maxfuel) * (maxfuel / fuelmul) ** (1 / fuelpower) + boost
        check = abs(reach - game_range) if game_range > 0 else 0.0
        if best is None or check < best["check"]:
            best = {"optimal_mass": optmass, "max_fuel_per_jump": maxfuel, "fuel_multiplier": fuelmul,
                    "fuel_power": fuelpower, "range": reach, "check": check}
    best.update(base_mass=unladen + reserve, tank_size=tank, internal_tank_size=reserve, range_boost=boost,
                game_range=game_range, multiplier=6 if "mkii" in item else 4,
                scoop=any("fuelscoop" in str(module.get("Item", "")).lower() for module in modules))
    logger.info("Galaxy Plotter ship: %s, %.2f ly by formula vs %.2f ly in game", item, best["range"], game_range)
    return best


PREMIUM_INJECTION = ("carbon", "germanium", "arsenic", "niobium", "yttrium", "polonium")   # 1 of each
_materials_raw: dict[str, int] = {}     # Raw materials, kept current by EDMC's state


def _note_materials(state: dict[str, Any]) -> None:
    raw = state.get("Raw") if isinstance(state, dict) else None
    if isinstance(raw, dict) and raw:
        _materials_raw.clear()
        for name, count in raw.items():
            try:
                _materials_raw[str(name).lower()] = int(count)
            except (TypeError, ValueError):
                pass


def _journal_materials() -> dict[str, int]:
    """Fallback: the newest Materials event in the game journal."""
    folder = _journal_dir()
    if not folder:
        return {}
    try:
        files = sorted((os.path.join(folder, item) for item in os.listdir(folder)
                        if item.startswith("Journal") and item.endswith(".log")),
                       key=os.path.getmtime, reverse=True)[:3]
    except OSError:
        return {}
    for path in files:
        found = None
        try:
            with open(path, encoding="utf-8", errors="replace") as stream:
                for line in stream:
                    if '"Materials"' in line:
                        try:
                            record = json.loads(line)
                        except ValueError:
                            continue
                        if record.get("event") == "Materials":
                            found = record
        except OSError:
            continue
        if found:
            return {str(item.get("Name", "")).lower(): int(item.get("Count") or 0)
                    for item in found.get("Raw") or [] if isinstance(item, dict)}
    return {}


def _injections_available() -> tuple[int, str]:
    """(premium FSD injections your materials allow, the material that runs out first); -1 if unknown."""
    stock = dict(_materials_raw) or _journal_materials()
    if not stock:
        return -1, ""
    counts = {name: int(stock.get(name, 0)) for name in PREMIUM_INJECTION}
    limit = min(counts, key=counts.get)
    return counts[limit], limit


def _injection_note() -> str:
    have, limit = _injections_available()
    if have < 0:
        return "Your materials aren't known yet (they load when the game starts)."
    if have == 0:
        return f"Not enough materials for a premium FSD injection (no {limit.title()})."
    return f"Your materials make {have} premium injection{'s' if have != 1 else ''} ({limit.title()} runs out first)."


def _planning_range(loadout: dict[str, Any], game_range: float) -> tuple[float, str]:
    """The jump range routes are planned with: a FULL fuel tank plus the cargo aboard now.
    The game's MaxJumpRange is the best case (almost no fuel), so legs planned with it can be a few
    ly too long once the tank is full, and Elite then adds an extra jump (found 24 Oct: IR-N d6-254
    to GA-A d39 was 531.5 ly; with 58.6 t of fuel the supercharged reach was about 529 ly)."""
    try:
        ship = _galaxy_ship(loadout)
    except RuntimeError:
        return game_range, ""          # FSD not in the table: keep the game's own figure
    cargo = _cargo_count()             # cargo and limpets, 1 t each
    unladen = ship["base_mass"] - ship["internal_tank_size"]
    mass = unladen + ship["tank_size"] + cargo
    reach = (ship["optimal_mass"] / mass * (ship["max_fuel_per_jump"] / ship["fuel_multiplier"])
             ** (1 / ship["fuel_power"]) + ship["range_boost"])
    if not 0 < reach <= MAX_SANE_RANGE or reach > game_range + 0.5:
        return game_range, ""
    return reach, "full tank" + (f" + {cargo} t cargo" if cargo else "")


def _spansh_galaxy(start: str, end: str, ship: dict[str, Any], options: dict[str, Any], cancelled
                   ) -> tuple[list[tuple[str, int]], dict[str, dict[str, Any]]]:
    """Ask Spansh's Galaxy Plotter for an exact route. Keeps the jumps that matter as waypoints:
    neutron boosts, refuel stops and the destination (the game plots the jumps between)."""
    reserve = ship["max_fuel_per_jump"] * GALAXY_RESERVE_JUMPS.get(str(_settings.get("fuel_safety", "normal")), 1)
    params = {"source": start, "destination": end,
              "is_supercharged": 1 if _galaxy_state.get("supercharged") else 0, "use_supercharge": 1,
              "use_injections": 1 if options.get("use_injections") else 0,
              # Tested 24 Oct (Sag A* to Beagle Point): use_injections alone = 114 jumps / 26 injections;
              # adding use_injections_when_required gave 249 injections, and that flag alone gave none.
              "use_injections_when_required": 0,
              "exclude_secondary": 1, "refuel_every_scoopable": 1,
              "fuel_power": ship["fuel_power"], "fuel_multiplier": ship["fuel_multiplier"],
              "optimal_mass": round(ship["optimal_mass"], 4), "base_mass": round(ship["base_mass"], 4),
              "tank_size": ship["tank_size"], "internal_tank_size": ship["internal_tank_size"],
              "reserve_size": round(reserve, 2), "max_fuel_per_jump": ship["max_fuel_per_jump"],
              "range_boost": ship["range_boost"], "max_time": 60, "cargo": _cargo_count(),
              "algorithm": str(options.get("galaxy_algorithm") or "optimistic"),
              "supercharge_multiplier": ship["multiplier"],
              "injection_multiplier": 2 if options.get("use_injections") else 0}   # 2 = premium
    logger.info("Plot New Route: asking Spansh Galaxy Plotter %s", params)
    reply = _spansh_request(SPANSH_GALAXY_URL, params)
    job = reply.get("job") if isinstance(reply, dict) else None
    if not job:
        error = reply.get("error") if isinstance(reply, dict) else None
        raise RuntimeError(str(error) if error else "Spansh did not accept the request.")
    result = _spansh_result(job, cancelled)
    jumps = [jump for jump in (result.get("jumps") if isinstance(result, dict) else None) or []
             if isinstance(jump, dict) and jump.get("name")]
    if isinstance(result, dict) and result.get("incomplete"):
        # Spansh ran out of search time and returned only the closest it got.
        try:
            short = f" (it got within {float(jumps[-1].get('distance_to_destination') or 0):,.0f} ly)"
        except (IndexError, TypeError, ValueError):
            short = ""
        logger.info("Galaxy Plotter: Spansh returned an incomplete route%s", short)
        raise RuntimeError(f"Spansh couldn't finish this galaxy route in time{short}.\n"
                           + ("Try again without FSD injections, " if options.get("use_injections") else "Try ")
                           + "a closer destination, or the Neutron Highway route type.")
    if len(jumps) < 2:
        raise RuntimeError("Spansh returned an empty route.")
    route, stops, count = [(str(jumps[0]["name"]), 0)], {}, 0
    if jumps[0].get("must_inject") or jumps[0].get("must_refuel"):
        stops[str(jumps[0]["name"]).casefold()] = {"refuel": bool(jumps[0].get("must_refuel")), "neutron": False,
                                                   "scoopable": bool(jumps[0].get("is_scoopable")),
                                                   "inject": bool(jumps[0].get("must_inject"))}
    for index, jump in enumerate(jumps[1:], start=1):
        count += 1
        # Spansh marks "inject" on the system where you synthesise it, before jumping on
        # (like "refuel"), so keep that system and the one the boosted jump reaches.
        after_inject = bool(jumps[index - 1].get("must_inject"))
        if (jump.get("has_neutron") or jump.get("must_refuel") or jump.get("must_inject") or after_inject
                or index == len(jumps) - 1):
            name = str(jump["name"])
            route.append((name, count))
            count = 0
            stops[name.casefold()] = {"refuel": bool(jump.get("must_refuel")), "neutron": bool(jump.get("has_neutron")),
                                      "scoopable": bool(jump.get("is_scoopable")),
                                      "inject": bool(jump.get("must_inject"))}
    logger.info("Plot New Route: Galaxy Plotter returned %d jumps, kept %d waypoints", len(jumps) - 1, len(route))
    return route, stops


def _plot_galaxy(origin: str, end: str, jump_range: float, options: dict[str, Any], cancelled
                 ) -> tuple[list[tuple[str, int]], dict[str, Any] | None, dict[str, dict[str, Any]]]:
    """Galaxy Plotter with the uncharted-space bridge. Spansh answers an unknown start only with
    "Unable to find route", so ask first whether it knows the start system."""
    global _galaxy_last_ship
    ship = _galaxy_last_ship = _galaxy_ship(_read_latest_loadout())
    start, bridge = origin, None
    if _spansh_coordinates(origin) is None:
        position = _start_coordinates(origin)
        if position is None:
            raise RuntimeError(f"Spansh doesn't know {origin} yet. A bridge route needs your"
                               " current system as the Start System.")
        bridge = _find_bridge(position, end, ship["range"] or jump_range, ship["multiplier"])
        start = bridge["system"]
    if cancelled():
        raise _PlotCancelled()
    route, stops = _spansh_galaxy(start, end, ship, options, cancelled)
    if bridge:
        first_leg = max(1, math.ceil(bridge["distance"] / max(ship["range"] or jump_range, 1)))
        route = [(origin, 0), (route[0][0], first_leg)] + route[1:]
    return route, bridge, stops


# ---------------------------------------------------------------------------
# Route progress bar (Jonathan's design, 23 Oct): a thin bar under the Jumps line,
# filled to your progress. It also carries On Route / Off Route / Arrived, so the
# lamp on the Jumps line hides while the bar is shown. Colours: green / red with a black
# empty part; with "Force EDMC theme colors", only EDMC's Highlighted / Normal Text are used
# (suite rule: never force colours beyond those two without a setting to turn it off).
# ---------------------------------------------------------------------------
_route_bar = None
_prefs_vars: dict[str, Any] = {}


def _route_colours() -> tuple[str, str]:
    """(on route, off route) colours for the lamp and the progress bar."""
    if _settings.get("force_theme_icons"):
        normal, highlight, _ = _palette()
        return highlight, normal
    return LAMP_ON, LAMP_OFF


def _route_bar_on() -> bool:
    return bool(_settings.get("show_progress_bar", True)) and _widget_alive(_route_bar)


class _RouteBar(tk.Canvas):
    """Thin progress bar. Off Route and Arrived are written in the middle of the bar."""

    def __init__(self, parent: tk.Misc, line: tk.Misc) -> None:
        super().__init__(parent, width=1, height=12, highlightthickness=0, bd=0)
        self._line = line               # the Jumps line: its font and width set the bar's size
        self._state: tuple[str | None, float] = (None, 0.0)
        self.bind("<Configure>", self.redraw)

    def font(self) -> Any:
        label = next((child for child in self._line.winfo_children() if child.winfo_class() == "Label"), None)
        try:
            return tkfont.Font(font=label.cget("font")) if label is not None else tkfont.nametofont("TkDefaultFont")
        except tk.TclError:
            return tkfont.nametofont("TkDefaultFont")

    def show(self, position: str | None, fraction: float) -> None:
        self._state = (position, max(0.0, min(1.0, fraction)))
        self.redraw()

    def redraw(self, _event: Any = None) -> None:
        if not _widget_alive(self):
            return
        font = self.font()
        line = int(font.metrics("linespace"))
        height = line + 2
        if int(self.cget("height")) != height:
            tk.Canvas.configure(self, height=height)
        width = self.winfo_width()
        background = _palette()[2]
        tk.Canvas.configure(self, bg=background)
        self.delete("all")
        if width <= 4:
            return
        position, fraction = self._state
        on_colour, off_colour = _route_colours()
        colour = off_colour if position == "off" else on_colour
        filled = width if position == "arrived" else round(width * fraction)
        thick = max(4, round(line * 0.3))
        top = (height - thick) // 2
        if _settings.get("force_theme_icons"):
            # Theme colours only: the empty part is the panel background, outlined in Normal Text.
            self.create_rectangle(0, top, width - 1, top + thick, fill=background, outline=_palette()[0])
        else:
            self.create_rectangle(0, top, width, top + thick, fill="black", outline="black")
        if filled > 0:
            self.create_rectangle(0, top, filled, top + thick, fill=colour, outline=colour)
        words = {"off": "Off Route", "arrived": "Arrived"}.get(position or "")
        if words:
            gap = font.measure(words) + font.measure("  ") * 2
            middle = width / 2
            self.create_rectangle(middle - gap / 2, 0, middle + gap / 2, height, fill=background, outline=background)
            self.create_text(middle, height / 2, text=words, fill=colour, font=font)


def _build_route_bar(block: tk.Frame, line: tk.Frame) -> None:
    """The bar is wider than the Jumps line but stops short of the panel edges (halfway between)."""
    global _route_bar
    _route_bar = _RouteBar(block, line)

    def fit(_event: Any = None) -> None:
        if not _widget_alive(_route_bar):
            return
        total, used = block.winfo_width(), line.winfo_reqwidth()
        if total <= 1:
            return
        wanted = max(used, int(used + (total - used) / 2))
        if int(_route_bar.cget("width")) != wanted:
            tk.Canvas.configure(_route_bar, width=wanted)
    block.bind("<Configure>", fit, add="+")
    line.bind("<Configure>", fit, add="+")


def _refresh_route_bar(position: str | None) -> None:
    if not _widget_alive(_route_bar):
        return
    if not _route_bar_on() or not _route_systems:
        _route_bar.pack_forget()
        return
    if not _route_bar.winfo_manager():
        _route_bar.pack(pady=(1, 2))
    done, left = _jump_counts()
    _route_bar.show(position, done / (done + left) if done + left else 0.0)


# ---------------------------------------------------------------------------
# Plugin settings page (File > Settings, this plugin's tab). Settings that are
# not needed mid-flight live here; the gear menu keeps the route actions.
# ---------------------------------------------------------------------------
PREFS_BUTTONS = (("Auto-Route Delay…", "_set_autoroute_delay"),
                 ("Load Keybindings…", "_load_binds_dialog"), ("Open Data Folder", "_open_data_folder"),
                 ("About", "_show_about"))


def _toplevels(widget: tk.Misc) -> list[tk.Misc]:
    found = []
    for child in widget.winfo_children():
        if isinstance(child, tk.Toplevel):
            found.append(child)
        found.extend(_toplevels(child))
    return found


def _prefs_action(command, page: tk.Misc):
    """EDMC's Settings window holds the input grab, so a window opened from it must take
    the grab over (and give it back when it closes), or it would not accept clicks."""
    def run() -> None:
        settings = page.winfo_toplevel()
        root = settings.nametowidget(".")
        before = set(_toplevels(root))
        command()
        for window in set(_toplevels(root)) - before:
            try:
                if not window.winfo_exists():
                    continue
                window.transient(settings)
                window.lift()
                window.grab_set()

                def give_back(event: Any, window: tk.Misc = window) -> None:
                    if event.widget is window and settings.winfo_exists():
                        try:
                            settings.grab_set()
                        except tk.TclError:
                            pass
                window.bind("<Destroy>", give_back, add="+")
            except tk.TclError:
                pass
    return run


def plugin_prefs(parent: Any, cmdr: Any = None, is_beta: bool = False) -> Any:
    import myNotebook as nb
    page = nb.Frame(parent)
    page.columnconfigure(0, weight=1)
    # EDMC's nb.Frame grids its own spacer in row 0, so everything here uses grid, from row 1.
    nb.Label(page, text=f"{TITLE} {VERSION}").grid(row=1, column=0, sticky=tk.W, padx=10, pady=(4, 8))
    _prefs_vars.clear()
    rows = (("show_progress_bar", "Show progress bar",
             "A thin bar under the Jumps line that fills as you go and shows On Route / Off Route."),
            ("force_theme_icons", "Force EDMC theme colors for plugin icons",
             "On Route uses your Highlighted Text colour and Off Route your Normal Text colour,\n"
             "instead of green and red (the lamp and the progress bar)."))
    row = 2
    for key, label, hint in rows:
        variable = tk.BooleanVar(page, value=bool(_settings.get(key, DEFAULT_SETTINGS[key])))
        _prefs_vars[key] = variable
        nb.Checkbutton(page, text=label, variable=variable).grid(row=row, column=0, sticky=tk.W, padx=10)
        nb.Label(page, text=hint, justify=tk.LEFT).grid(row=row + 1, column=0, sticky=tk.W, padx=30, pady=(0, 8))
        row += 2
    pace = nb.Frame(page)
    pace.grid(row=row, column=0, sticky=tk.W, padx=10, pady=(0, 8))
    nb.Label(pace, text="Minutes per jump for the time estimate, until your pace is learned:").grid(
        row=1, column=0, sticky=tk.W)
    pace_var = tk.StringVar(page, value=f"{_default_pace():g}")
    _prefs_vars["eta_minutes_per_jump"] = pace_var
    entry_class = getattr(nb, "EntryMenu", None) or ttk.Entry
    entry_class(pace, textvariable=pace_var, width=6).grid(row=1, column=1, sticky=tk.W, padx=(6, 0))
    nb.Label(pace, text="Gaps between waypoints longer than three times this count as a break,\n"
             "so time spent idle does not slow the estimate down.", justify=tk.LEFT).grid(
        row=2, column=0, columnspan=2, sticky=tk.W, padx=20)
    row += 1
    buttons = nb.Frame(page)
    buttons.grid(row=row, column=0, sticky=tk.W, padx=10, pady=(4, 10))
    column = 0
    for label, name in PREFS_BUTTONS:
        command = globals().get(name)
        if callable(command):
            ttk.Button(buttons, text=label, command=_prefs_action(command, page)).grid(row=1, column=column, padx=(0, 6))
            column += 1
    # Required Interface owns the shared contrast preference and rendering.
    try:
        from plug import invoke
        invoke("Navigator Interface", None, "navigator_background_preferences",
               page, "Neutron_Highway_Navigator")
    except ImportError:
        pass
    return page


def _apply_prefs_page() -> None:
    """Settings > OK: keep what was ticked on our page."""
    changed = False
    for key, variable in list(_prefs_vars.items()):
        try:
            if key == "eta_minutes_per_jump":
                value = min(60.0, max(0.25, float(str(variable.get()).strip())))
            else:
                value = bool(variable.get())
        except (tk.TclError, ValueError):
            continue
        if _settings.get(key) != value:
            _settings[key] = value
            changed = True
    _prefs_vars.clear()
    if changed:
        _save_settings()
        _refresh_route_label()


def _save_plotted_csv(route: list[tuple[str, int]]) -> str | None:
    """Keep a CSV copy of every plotted route (to reload after a Cancel Route, or to share)."""
    folder = os.path.join(DATA_DIR, "plotted_routes")
    clean = lambda name: re.sub(r"[^A-Za-z0-9 _.-]", "", name).strip().replace(" ", "_")[:40] or "system"
    stamp = datetime.now().strftime("%Y-%m-%d_%H%M%S")
    path = os.path.join(folder, f"{stamp}_{clean(route[0][0])}_to_{clean(route[-1][0])}.csv")
    try:
        os.makedirs(folder, exist_ok=True)
        with open(path, "w", encoding="utf-8", newline="") as stream:
            writer = csv.writer(stream)
            writer.writerow(["System Name", "Jumps"])
            writer.writerows(route)
        return path
    except OSError:
        logger.exception("Could not save the plotted route CSV")
        return None

def _ship_line(profile: dict[str, Any], jump_range: float | None = None) -> str:
    if jump_range is None and not profile["ok"]:
        line = f"{profile['label']} Enter your jump range below."
    else:
        shown = profile["range"] if jump_range is None else jump_range
        note = profile.get("range_note") if jump_range is None or jump_range == profile["range"] else ""
        detail = f" ({note}; best case {profile['best_range']:.2f})" if note else ""
        line = f"{profile['label']} · {shown:.2f} ly{detail} · x{profile['multiplier']} boost"
    cargo = _cargo_count()
    if cargo > 0 and not profile.get("range_note"):
        line += (f"\nCarrying {cargo} t of cargo: your real jump range is lower,"
                 " so the route may need extra jumps.")
    return line

def _game_destination() -> str:
    """The system you have targeted or plotted to in Elite, as the default End System.
    The end of the game's plotted route wins; otherwise the FSD target from Status.json, only when
    it is a whole system (Body 0, so not a station, body or carrier). Never the system you are in,
    and never a system on the route already loaded (mid-route the game targets our own Next)."""
    here = str(_snapshot.get("location", {}).get("system_name") or "").casefold()
    ours = {name.casefold() for name in _route_systems}
    candidates = []
    route = [item for item in (_read_journal_json("NavRoute.json") or {}).get("Route") or [] if isinstance(item, dict)]
    if route:
        candidates.append(str(route[-1].get("StarSystem") or ""))
    target = (_read_journal_json("Status.json") or {}).get("Destination")
    if isinstance(target, dict) and not target.get("Body"):
        candidates.append(str(target.get("Name") or ""))
    for name in candidates:
        if name and name.casefold() != here and name.casefold() not in ours:
            return name
    return ""


def _open_plot_popup() -> None:
    """Gear > Plot New Route: Start / End / Efficiency, ship read automatically."""
    global _plot_popup, _plot_close_callback
    if _plot_close_callback is not None:
        _plot_close_callback()
    if _plot_popup is not None:
        try:
            _plot_popup.destroy()
        except tk.TclError:
            pass
    profile = _ship_profile()
    window = _plot_popup = tk.Toplevel(_app_frame)
    window.title("Plot New Route")
    try:
        window.transient(_app_frame.winfo_toplevel())
    except tk.TclError:
        pass
    state: dict[str, Any] = {"stage": "input", "route": None, "cancelled": False,
                             "lookup": None, "profile": profile, "workers":0, "pump":None}
    results: queue.Queue = queue.Queue()

    body = tk.Frame(window)
    body.pack(fill=tk.BOTH, expand=True, padx=12, pady=10)
    body.columnconfigure(1, weight=1)
    info = tk.Label(body, text=_ship_line(profile), justify=tk.LEFT, anchor=tk.W, wraplength=380)
    info.grid(row=0, column=0, columnspan=2, sticky=tk.W, pady=(0, 8))

    def field(row: int, label: str, value: str) -> tk.Entry:
        tk.Label(body, text=label, anchor=tk.W).grid(row=row, column=0, sticky=tk.W, padx=(0, 8), pady=3)
        entry = tk.Entry(body, width=34)
        entry.insert(0, value)
        entry.grid(row=row, column=1, sticky=tk.EW, pady=3)
        return entry

    start = field(1, "Start System", str(_snapshot.get("location", {}).get("system_name") or ""))
    end = field(2, "End System", _game_destination() or str(_settings.get("plot_last_end") or ""))
    suggestions = tk.Listbox(body, height=5, activestyle="none", exportselection=False)
    suggestions.grid(row=3, column=1, sticky=tk.EW)
    suggestions.grid_remove()
    efficiency = field(4, "Efficiency (%)", str(_settings.get("plot_efficiency", 70)))
    range_entry = None
    if not profile["ok"]:
        range_entry = field(5, "Jump Range (ly)", f"{profile['range']:.2f}" if profile["range"] > 0 else "")
    status = tk.Label(body, text="", justify=tk.LEFT, anchor=tk.W, wraplength=380)
    status.grid(row=20, column=0, columnspan=2, sticky=tk.W, pady=(8, 0))
    # Route Type: Neutron Highway or Road to Riches (its own settings, shown only for it).
    saved_kind = _settings.get("plot_type")
    kind_var = tk.StringVar(window, value=ROUTE_TYPES[ROUTE_KINDS.index(saved_kind)]
                            if saved_kind in ROUTE_KINDS else ROUTE_TYPES[0])
    typebar = tk.Frame(window)
    typebar.pack(fill=tk.X, padx=12, pady=(10, 0), before=body)
    tk.Label(typebar, text="Route Type", anchor=tk.W).pack(side=tk.LEFT, padx=(0, 8))
    # The suite's standard dropdown: a read-only ttk.Combobox (as in Radio, Docking, Interface, Voice).
    ttk.Combobox(typebar, textvariable=kind_var, values=ROUTE_TYPES, state="readonly",
                 width=max(len(name) for name in ROUTE_TYPES) + 2).pack(side=tk.LEFT)
    riches_entries = {key: field(10 + offset, label, str(_settings.get(key, DEFAULT_SETTINGS[key])))
                      for offset, (key, label) in enumerate(RICHES_FIELDS)}
    end_caption = body.grid_slaves(row=2, column=0)[0]
    neutron_only = body.grid_slaves(row=4)
    riches_only = [widget for row in range(10, 10 + len(RICHES_FIELDS)) for widget in body.grid_slaves(row=row)]
    algorithm_names = [name for name, _ in GALAXY_ALGORITHMS]
    saved_algorithm = next((name for name, code in GALAXY_ALGORITHMS
                            if code == _settings.get("galaxy_algorithm")), algorithm_names[0])
    algorithm_var = tk.StringVar(window, value=saved_algorithm)
    galaxy_only = [tk.Label(body, text="Routing", anchor=tk.W),
                   ttk.Combobox(body, textvariable=algorithm_var, values=algorithm_names, state="readonly",
                                width=max(len(name) for name in algorithm_names) + 2)]
    galaxy_only[0].grid(row=15, column=0, sticky=tk.W, padx=(0, 8), pady=3)
    galaxy_only[1].grid(row=15, column=1, sticky=tk.W, pady=3)
    # FSD injections are rare (far reaches of the galaxy only): opt-in, off every time the window opens.
    inject_var = tk.BooleanVar(window, value=False)
    inject_box = tk.Checkbutton(body, text="Use FSD injections when needed (premium)", variable=inject_var,
                                anchor=tk.W)
    inject_note = tk.Label(body, text=_injection_note(), anchor=tk.W, justify=tk.LEFT, wraplength=380)
    inject_box.grid(row=16, column=0, columnspan=2, sticky=tk.W, pady=(4, 0))
    inject_note.grid(row=17, column=0, columnspan=2, sticky=tk.W, padx=(22, 0))
    galaxy_only += [inject_box, inject_note]

    def show_kind(*_args: Any) -> None:
        chosen = ROUTE_KINDS[ROUTE_TYPES.index(kind_var.get())] if kind_var.get() in ROUTE_TYPES else "neutron"
        riches = chosen in SCAN_KINDS
        for widget in neutron_only:
            widget.grid() if chosen == "neutron" else widget.grid_remove()
        for widget in riches_only:
            widget.grid() if riches else widget.grid_remove()
        for widget in galaxy_only:
            widget.grid() if chosen == "galaxy" else widget.grid_remove()
        end_caption.configure(text="End System (optional)" if riches else "End System")
        back_to_input()
    buttons = tk.Frame(window)
    buttons.pack(side=tk.BOTTOM, pady=(4, 10))
    plot_button = tk.Button(buttons, text="Plot Route", width=12, padx=12, pady=6)
    plot_button.pack(side=tk.LEFT, padx=6)
    tk.Button(buttons, text="Cancel", width=10, padx=12, pady=6,
              command=lambda: close()).pack(side=tk.LEFT, padx=6)

    def close() -> None:
        global _plot_popup, _plot_close_callback
        state["cancelled"] = True
        for key in ("lookup","pump"):
            callback=state.get(key)
            if callback is not None:
                try: window.after_cancel(callback)
                except tk.TclError: pass
                state[key]=None
        if _plot_popup is window:
            _plot_popup=None
            _plot_close_callback=None
        try:
            window.destroy()
        except tk.TclError:
            pass

    def back_to_input(_event: Any = None) -> None:
        if state["stage"] == "result":
            state["stage"], state["route"] = "input", None
            plot_button.configure(text="Plot Route", state=tk.NORMAL)
            status.configure(text="")

    def schedule_pump():
        if not state["cancelled"] and state["workers"] and state["pump"] is None:
            state["pump"] = window.after(100,pump)

    # End System suggestions: 3+ letters, looked up in the background.
    def lookup_later(_event: Any = None) -> None:
        back_to_input()
        if state["lookup"] is not None:
            window.after_cancel(state["lookup"])
        state["lookup"] = window.after(400, lookup_now)

    def lookup_now() -> None:
        state["lookup"] = None
        text = end.get().strip()
        if len(text) < 3:
            suggestions.grid_remove()
            return

        def worker() -> None:
            try:
                results.put(("names", text, _spansh_names(text)))
            except Exception as error:
                logger.info("Plot New Route: no suggestions for %r (%s)", text, error)
                results.put(("names",text,[]))
        state["workers"] += 1
        threading.Thread(target=worker, daemon=True).start()
        schedule_pump()

    def pick_suggestion(_event: Any = None) -> None:
        chosen = suggestions.curselection()
        if chosen:
            end.delete(0, tk.END)
            end.insert(0, suggestions.get(chosen[0]))
            suggestions.grid_remove()

    end.bind("<KeyRelease>", lookup_later)
    suggestions.bind("<<ListboxSelect>>", pick_suggestion)
    for entry in (start, efficiency) + ((range_entry,) if range_entry is not None else ()):
        entry.bind("<KeyRelease>", back_to_input)

    def plot_or_load() -> None:
        if state["stage"] == "result":
            load_route()
            return
        origin, target = start.get().strip(), end.get().strip()
        kind = ROUTE_KINDS[ROUTE_TYPES.index(kind_var.get())] if kind_var.get() in ROUTE_TYPES else "neutron"
        if not origin or (not target and kind not in SCAN_KINDS):
            status.configure(text="Enter both a Start System and an End System." if kind not in SCAN_KINDS
                             else "Enter a Start System.")
            return
        options: dict[str, float] = {}
        if kind in SCAN_KINDS:
            try:
                options = {key: float(riches_entries[key].get().replace(",", "").strip())
                           for key, _ in RICHES_FIELDS}
            except ValueError:
                options = {}
            if len(options) != len(RICHES_FIELDS) or min(options.values()) <= 0:
                status.configure(text="The Road to Riches settings must be numbers above 0.")
                return
        elif kind == "galaxy":
            options = {"galaxy_algorithm": dict(GALAXY_ALGORITHMS).get(algorithm_var.get(), "optimistic"),
                       "use_injections": bool(inject_var.get())}
        try:
            percent = int(float(efficiency.get().strip()))
        except ValueError:
            percent = -1
        if kind != "neutron":
            percent = int(_settings.get("plot_efficiency", 70))   # neutron plotter only
        elif not 1 <= percent <= 100:
            status.configure(text="Efficiency must be a number from 1 to 100.")
            return
        fresh = _ship_profile()                 # re-check the ship on every request
        state["profile"] = fresh
        if fresh["ok"]:
            jump_range = fresh["range"]
        else:
            try:
                jump_range = float((range_entry.get() if range_entry is not None else "").strip())
            except ValueError:
                jump_range = 0.0
            if not 0 < jump_range <= MAX_SANE_RANGE:
                status.configure(text="Ship data not found - enter your jump range (ly).")
                return
        info.configure(text=_ship_line(fresh, jump_range))
        plot_button.configure(state=tk.DISABLED)
        status.configure(text="Asking Spansh to plot the route…")
        state["stage"] = "plotting"
        multiplier = fresh["multiplier"]

        def worker() -> None:
            try:
                if kind == "galaxy":
                    route, bridge, bodies = _plot_galaxy(origin, target, jump_range, options,
                                                         lambda: state["cancelled"])
                elif kind in SCAN_KINDS:
                    route, bridge, bodies = _plot_riches(origin, target, jump_range, multiplier, options,
                                                         lambda: state["cancelled"],
                                                         _spansh_exo if kind == "exo" else None)
                else:
                    route, bridge = _plot_with_bridge(origin, target, jump_range, percent, multiplier,
                                                      lambda: state["cancelled"])
                    bodies = {}
                results.put(("route", route, (target, percent, bridge, kind, bodies, options)))
            except _PlotCancelled:
                pass
            except RuntimeError as error:
                results.put(("error", str(error), None))
            except Exception:
                logger.exception("Plot New Route failed")
                results.put(("error", "Unexpected error - see the EDMC log.", None))
        state["workers"] += 1
        threading.Thread(target=worker, daemon=True).start()
        schedule_pump()

    def load_route() -> None:
        route = state["route"]
        if not route:
            return
        if _route_systems and not messagebox.askyesno(
                "Replace Route", "Replace the current route with the new one?", parent=window):
            return
        saved = _save_plotted_csv(route)
        target, percent = state["inputs"]
        kind = state.get("kind") or "neutron"
        if target or kind == "neutron":
            _settings["plot_last_end"] = target
        _settings["plot_efficiency"] = percent
        _settings["plot_type"] = kind
        for key, value in (state.get("options") or {}).items():
            if key == "use_injections":
                continue                     # never remembered: injections are a one-off choice
            _settings[key] = int(value) if isinstance(value, float) and value.is_integer() else value
        _save_settings()
        _set_route([system for system, _ in route], _snapshot.get("location", {}).get("system_name"),
                   kind=kind, bodies=state.get("bodies"))
        logger.info("Plot New Route: loaded %d waypoints (CSV copy: %s)", len(route), saved)
        close()
        bridge = state.get("bridge")
        if kind == "galaxy":
            refuels = sum(1 for item in _route_bodies.values() if isinstance(item, dict) and item.get("refuel"))
            injects = sum(1 for item in _route_bodies.values() if isinstance(item, dict) and item.get("inject"))
            _set_status(f"Galaxy route loaded: {sum(jumps for _, jumps in route)} jumps, "
                        f"{refuels} refuel stop{'s' if refuels != 1 else ''}"
                        + (f", {injects} FSD injection{'s' if injects != 1 else ''}." if injects else ".")
                        + (f" Starts via {bridge['system']} ({bridge['distance']:.0f} ly)." if bridge else ""))
        elif bridge and kind in SCAN_KINDS:
            _set_status(f"Uncharted space: your {'Exomastery route' if kind == 'exo' else 'Road to Riches'} starts from {bridge['system']} "
                        f"({bridge['distance']:.0f} ly).")
        elif bridge:
            _set_status(f"Uncharted space: bridging via {bridge['system']} "
                        f"({bridge['distance']:.0f} ly) onto the Neutron Highway.")
        elif kind in SCAN_KINDS:
            _set_status(f"{'Exomastery' if kind == 'exo' else 'Road to Riches'} loaded: {_count(len(_route_bodies), 'system')} to scan.")
        else:
            _set_status(f"Route loaded: {len(route)} waypoints.")

    plot_button.configure(command=plot_or_load)
    kind_var.trace_add("write", show_kind)
    algorithm_var.trace_add("write", lambda *_args: back_to_input())
    inject_var.trace_add("write", lambda *_args: back_to_input())
    for entry in riches_entries.values():
        entry.bind("<KeyRelease>", back_to_input)
    show_kind()

    # Results from the background threads are handled here, on EDMC's own thread.
    def pump() -> None:
        state["pump"] = None
        if state["cancelled"]:
            return
        try:
            while True:
                kind, payload, extra = results.get_nowait()
                state["workers"] = max(0,state["workers"]-1)
                if kind == "names":
                    if payload == end.get().strip() and extra:
                        suggestions.delete(0, tk.END)
                        for name in extra:
                            suggestions.insert(tk.END, name)
                        suggestions.grid()
                    elif payload == end.get().strip():
                        suggestions.grid_remove()
                elif kind == "route":
                    state["stage"], state["route"] = "result", payload
                    state["inputs"], state["bridge"] = extra[:2], extra[2]
                    state["kind"], state["bodies"], state["options"] = extra[3], extra[4], extra[5]
                    lead = _bridge_text(extra[2], extra[3]) + "\n\n" if extra[2] else ""
                    status.configure(text=lead + f"{payload[0][0]} → {payload[-1][0]}\n"
                                          + _route_summary(payload, extra[3], extra[4]))
                    plot_button.configure(text="Load Route", state=tk.NORMAL)
                elif kind == "error":
                    state["stage"] = "input"
                    status.configure(text="Plot Failed: "+payload+"\nYour Loaded Route Is Unchanged.")
                    plot_button.configure(text="Retry Plot", state=tk.NORMAL)
        except queue.Empty:
            pass
        schedule_pump()

    window.protocol("WM_DELETE_WINDOW", close)
    window.bind("<Escape>", lambda _event: close())
    _plot_close_callback = close
    _theme_dialog(window)
    window.update_idletasks()
    root = _app_frame.winfo_toplevel()
    width, height = window.winfo_reqwidth(), window.winfo_reqheight()
    x = min(max(0, root.winfo_rootx() + 40), max(0, window.winfo_screenwidth() - width))
    y = min(max(0, root.winfo_rooty() + 40), max(0, window.winfo_screenheight() - height - 40))
    window.geometry(f"+{x}+{y}")
    (end if start.get() else start).focus_set()

class _IconButton(tk.Canvas):
    """A copy button sized to the text beside it."""

    def __init__(self, parent: tk.Misc, kind: str, command, reference: tk.Label,
                 colour_source: tk.Button) -> None:
        try:
            size = max(14, int(tkfont.Font(font=reference.cget("font")).metrics("linespace")))
        except (tk.TclError, ValueError):
            size = 20
        super().__init__(parent, width=size, height=size, highlightthickness=0, bd=0, cursor="hand2")
        self._size, self._kind, self._command = size, kind, command
        self._reference, self._source = reference, colour_source
        self._enabled = True
        self.bind("<Button-1>", self._clicked)
        self.bind("<Map>", self._draw)
        _theme_controls.append(self)
        self.configure(takefocus=True)
        self.bind("<Return>",self._clicked)
        self.bind("<space>",self._clicked)

    def _clicked(self, _event: Any = None) -> None:
        if self._enabled:
            self._command()

    def _draw(self, _event: Any = None) -> None:
        background = self._reference.cget("background")
        colour = getattr(self, "_foreground", None) or self._source.cget("foreground")
        if not self._enabled:
            colour = self._source.cget("disabledforeground") or colour
        s, width = self._size, max(1, self._size // 10)
        tk.Canvas.configure(self, bg=background, cursor="hand2" if self._enabled else "")
        self.delete("all")
        self.create_rectangle(s * 0.40, s * 0.12, s * 0.86, s * 0.58, outline=colour, width=width)
        self.create_rectangle(s * 0.14, s * 0.40, s * 0.60, s * 0.86, outline=colour,
                              fill=background, width=width)

    def configure(self, cnf: Any = None, **kw: Any) -> Any:
        # EDMC treats every hand-cursor widget as text and sends foreground/font,
        # even to canvases. Consume those drawing properties instead of passing
        # unsupported Tcl options through. __setitem__ supplies a dict, not kwargs.
        if isinstance(cnf, dict):
            kw = {**cnf, **kw}
            cnf = None
        redraw = False
        colour = kw.pop("foreground", kw.pop("fg", None))
        if colour is not None:
            self._foreground = colour
            redraw = True
        font = kw.pop("font", None)
        if font is not None:
            size = max(14, int(tkfont.Font(font=font).metrics("linespace")))
            self._size = size
            kw.update(width=size, height=size)
            redraw = True
        if "state" in kw:
            self._enabled = kw.pop("state") != tk.DISABLED
            redraw = True
        if "background" in kw or "bg" in kw:
            redraw = True
        result = None
        if cnf or kw:
            result = tk.Canvas.configure(self, cnf, **kw)
        if redraw and hasattr(self, "_source"):
            self._draw()
        return result

    config = configure

def _gear_inside(x: float, y: float) -> bool:
    for cx, cy, root, tip, hole, teeth, phase in _GEARS:
        dx, dy = x - cx, y - cy
        r = math.hypot(dx, dy)
        if r > tip or r < hole:
            continue
        if r <= root:
            return True
        # trapezoid teeth: flat top, sloped flanks
        u = (math.atan2(dy, dx) / (2 * math.pi) * teeth + phase) % 1.0
        d = abs(u - 0.5)
        if d <= 0.15:
            edge = tip
        elif d <= 0.27:
            edge = tip - (tip - root) * (d - 0.15) / 0.12
        else:
            edge = root
        if r <= edge:
            return True
    return False

def _gear_coverage(size: int, samples: int = 4) -> list[list[float]]:
    """How much of each pixel the gears cover (0..1), using 4x4 supersampling for smooth edges."""
    grid = []
    total = samples * samples
    for py in range(size):
        row = []
        for px in range(size):
            hits = 0
            for sy in range(samples):
                for sx in range(samples):
                    if _gear_inside((px + (sx + 0.5) / samples) / size, (py + (sy + 0.5) / samples) / size):
                        hits += 1
            row.append(hits / total)
        grid.append(row)
    return grid

def _render_gear_icon() -> None:
    """Draw the gears onto the settings button in the theme's button colour."""
    global _gear_image
    if _cog_button is None or _title_label is None:
        return
    try:
        try:
            size = max(14, int(tkfont.Font(font=_title_label.cget("font")).metrics("linespace")))
        except (tk.TclError, ValueError):
            size = 20
        fg = [v / 257 for v in _cog_button.winfo_rgb(_cog_button.cget("foreground"))]
        bg = [v / 257 for v in _cog_button.winfo_rgb(_cog_button.cget("background"))]
        coverage = _gear_coverage(size)
        rows = []
        for row in coverage:
            rows.append("{" + " ".join(
                "#%02x%02x%02x" % tuple(round(b + (f - b) * a) for f, b in zip(fg, bg)) for a in row) + "}")
        image = tk.PhotoImage(width=size, height=size)
        image.put(" ".join(rows), to=(0, 0))
        for y, row in enumerate(coverage):
            for x, amount in enumerate(row):
                if amount == 0:
                    image.tk.call(image.name, "transparency", "set", x, y, 1)
        _cog_button.configure(image=image)
        _gear_image = image          # keep a reference or Tk discards the image
    except tk.TclError:
        logger.exception("Could not draw the settings icon; keeping the text gear")

def _completed_systems() -> list[str]:
    """Systems reached by jumping (the starting system is not a jump), matching the count shown."""
    return _route_systems[1:_route_index + 1] if _route_systems else []

def _remaining_systems() -> list[str]:
    return _route_systems[_route_index + 1:] if _route_systems else []

def _show_systems_popup(title: str, systems: list[str], empty_text: str) -> None:
    """A small scrollable list with a large OK button, sized to fit the screen."""
    global _systems_popup
    if _systems_popup is not None:
        try:
            _systems_popup.destroy()
        except tk.TclError:
            pass
    window = _systems_popup = tk.Toplevel(_app_frame)
    window.title(title)
    try:
        window.transient(_app_frame.winfo_toplevel())
    except tk.TclError:
        pass
    lines = systems or [empty_text]
    body = tk.Frame(window)
    body.pack(side=tk.TOP, fill=tk.BOTH, expand=True, padx=8, pady=(8, 4))
    listbox = tk.Listbox(body, activestyle="none", exportselection=False, highlightthickness=0)
    try:
        line_height = int(tkfont.Font(font=listbox.cget("font")).metrics("linespace"))
    except (tk.TclError, ValueError):
        line_height = 16
    max_rows = max(5, int(window.winfo_screenheight() * 0.6 / max(line_height, 1)))
    listbox.configure(height=min(len(lines), max_rows, 25),
                      width=min(max(20, max(len(line) for line in lines) + 2), 45))
    for line in lines:
        listbox.insert(tk.END, line)
    if len(lines) > int(listbox.cget("height")):
        scrollbar = tk.Scrollbar(body, orient=tk.VERTICAL, command=listbox.yview,
                                 width=max(16, line_height))   # wide enough for a finger
        listbox.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
    listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

    # Tap a name to copy it; press and drag to scroll (touch-friendly).
    copied = tk.Label(window, text="Tap a system to copy it", anchor=tk.CENTER)
    press = {"y": 0, "dragging": False}

    def on_press(event: Any) -> str:
        press["y"], press["dragging"] = event.y, False
        listbox.scan_mark(event.x, event.y)
        return "break"

    def on_motion(event: Any) -> str:
        if press["dragging"] or abs(event.y - press["y"]) > 6:
            press["dragging"] = True
            listbox.scan_dragto(event.x, event.y, gain=1)
        return "break"

    def on_release(event: Any) -> str:
        if not press["dragging"] and systems:
            index = listbox.nearest(event.y)
            box = listbox.bbox(index)       # nearest() picks the last row for taps below the list
            if 0 <= index < len(systems) and box and box[1] <= event.y <= box[1] + box[3]:
                _copy_system(systems[index])
                listbox.selection_clear(0, tk.END)
                listbox.selection_set(index)
                copied.configure(text=f"Copied: {systems[index]}")
                _set_status(f"Copied: {systems[index]}")
        return "break"

    listbox.bind("<Button-1>", on_press)
    listbox.bind("<B1-Motion>", on_motion)
    listbox.bind("<ButtonRelease-1>", on_release)

    ok = tk.Button(window, text="OK", width=10, padx=12, pady=6, command=window.destroy)
    # Pack the bottom row before the list so OK always keeps its space on small screens:
    # OK at the very bottom, the "Copied" line just above it, the list takes the rest.
    ok.pack(side=tk.BOTTOM, pady=(4, 10), before=body)
    if systems:
        copied.pack(side=tk.BOTTOM, pady=(0, 2), before=body)
    ok.focus_set()
    window.bind("<Return>", lambda _event: window.destroy())
    window.bind("<Escape>", lambda _event: window.destroy())

    # Place it next to EDMC, kept fully on screen.
    _theme_dialog(window)
    window.update_idletasks()
    root = _app_frame.winfo_toplevel()
    width, height = window.winfo_reqwidth(), window.winfo_reqheight()
    x = min(max(0, root.winfo_rootx() + 40), max(0, window.winfo_screenwidth() - width))
    y = min(max(0, root.winfo_rooty() + 40), max(0, window.winfo_screenheight() - height - 40))
    window.geometry(f"+{x}+{y}")

def _show_completed() -> None:
    done = _completed_systems()
    _show_systems_popup(f"Jumps Complete ({len(done)})", done, "No jumps complete yet.")

def _show_remaining() -> None:
    left = _remaining_systems()
    _show_systems_popup(f"Jumps Left ({len(left)})", left, "No jumps left - you have arrived.")

def _apply_header_spacing() -> None:
    """Re-measure the header spacing once EDMC has applied its theme font (no underline)."""
    _update_header_spacing()


def _journal_dir():
    configured = config.get_str("journaldir", default="")
    if configured and os.path.isdir(configured):
        return configured
    fallback = os.path.join(os.path.expanduser("~"), "Saved Games", "Frontier Developments", "Elite Dangerous")
    return fallback if os.path.isdir(fallback) else None


def _load_settings():
    global _settings
    _settings = dict(DEFAULT_SETTINGS)
    try:
        with open(SETTINGS_PATH, encoding="utf-8") as stream:
            saved = json.load(stream)
        if isinstance(saved, dict):
            for key in DEFAULT_SETTINGS:
                if key in saved:
                    _settings[key] = saved[key]
    except FileNotFoundError:
        pass
    except (OSError, ValueError):
        logger.exception("Could not read Navigator settings")


def _save_settings():
    try:
        _write_json(SETTINGS_PATH, {key: _settings[key] for key in DEFAULT_SETTINGS})
        return True
    except OSError:
        logger.exception("Could not save Navigator settings")
        return False


def _set_status(text):
    global _status_expiry
    if _stopped or _app_frame is None or _status_label is None:
        return
    if _status_expiry is not None:
        _app_frame.after_cancel(_status_expiry)
        _status_expiry = None
    _status_label.configure(text=text)
    if text:
        _status_label.grid()
        _status_expiry = _app_frame.after(8000, lambda: _set_status(""))
    else:
        _status_label.grid_remove()


def _refresh_route_label():
    if _title_label is not None and not _widget_alive(_title_label):
        return      # the panel was never built (or EDMC has destroyed it)
    current, following, end = _current_system(), _next_system(), _end_system()
    done, left = _jump_counts()
    collapsed = bool(_settings.get("collapsed"))
    if _title_label is not None:
        _title_label.configure(text=TITLE + (" (Hidden)" if collapsed else ""))
    _update_header_spacing()
    _refresh_position()
    _refresh_scan()
    for widget in _route_rows:
        widget.grid() if _route_systems and not collapsed else widget.grid_remove()
    if _collapse_button is not None:
        _collapse_button.configure(text="\U0001f53d" if collapsed else "\U0001f53c")
        _collapse_button.grid() if _route_systems else _collapse_button.grid_remove()
    if _current_label is not None:
        _current_label.configure(text=_waypoint_word() + ": " + (current or "Unknown"))
        _next_label.configure(text="Next: " + (following or "Unknown"))
        _end_label.configure(text="End: " + (end or "Unknown"))
        _done_label.configure(text=f": {done}  |  ")
        _left_label.configure(text=f": {left}")
        for button, name in ((_copy_current_button,current),(_copy_next_button,following),(_copy_end_button,end)):
            button.configure(state=tk.NORMAL if name else tk.DISABLED)


def _update_header_spacing():
    if _title_label is None or _cog_button is None:
        return
    font = tkfont.Font(font=_title_label.cget("font"))
    _title_label.configure(padx=0, borderwidth=0)
    _cog_button.configure(padx=0, highlightthickness=0)
    _cog_button.pack_configure(padx=(font.measure(" "),0))


def _apply_theme():
    global _theme_pending
    _theme_pending = None
    if _stopped or _app_frame is None or not _app_frame.winfo_exists() or not _widget_alive(_cog_button):
        return
    normal, highlight, background = _palette()
    # Settings gear uses Normal Text, like the header it sits beside.
    _cog_button.configure(foreground=normal, background=background, activeforeground=normal,
                          activebackground=background, disabledforeground=normal)
    for widget in _theme_controls:
        if widget.winfo_exists():
            widget.configure(foreground=highlight, background=background)
    _render_gear_icon()
    _update_header_spacing()
    _refresh_position()


def _theme_dialog(window):
    from theme import theme
    pending = [window]
    while pending:
        widget = pending.pop()
        pending.extend(widget.winfo_children())
        if hasattr(theme,"update"):
            theme.update(widget)
        if "background" in widget.keys():
            widget.configure(background=_palette()[2])


def _show_about():
    messagebox.showinfo("About " + TITLE, f"Version {VERSION}\n\n{ABOUT_TEXT}", parent=_app_frame)


def _settings_menu():
    menu = tk.Menu(_app_frame, tearoff=0)
    menu.add_command(label="Plot New Route...", command=_open_plot_popup)
    menu.add_command(label="Load Route", command=_load_route_dialog)
    menu.add_command(label="Cancel Route", command=_cancel_route,
                     state=tk.NORMAL if _route_systems else tk.DISABLED)
    _add_fuel_menu(menu)
    return menu


def _show_settings_menu():
    menu = _settings_menu()
    try:
        menu.tk_popup(_cog_button.winfo_rootx(), _cog_button.winfo_rooty()+_cog_button.winfo_height())
    finally:
        menu.grab_release()


def plugin_start3(plugin_dir):
    global PLUGIN_DIR, DATA_DIR, STATE_PATH, ROUTE_PATH, SETTINGS_PATH, _stopped
    _stopped = False
    PLUGIN_DIR = os.path.abspath(plugin_dir)
    appdir = getattr(config,"app_dir_path",None) or getattr(config,"app_dir",None)
    if not appdir:
        appdir = os.path.join(os.environ.get("LOCALAPPDATA",os.path.expanduser("~")),"EDMarketConnector")
    DATA_DIR = os.path.join(os.fspath(appdir),"NeutronHighwayNavigator")
    os.makedirs(DATA_DIR,exist_ok=True)
    STATE_PATH = os.path.join(DATA_DIR,"navigator_state.json")
    ROUTE_PATH = os.path.join(DATA_DIR,"active_route.json")
    SETTINGS_PATH = os.path.join(DATA_DIR,"settings.json")
    _load_settings()
    # On first use, take a read-only copy of the existing project's route.
    # Afterwards each plugin has its own route and progress.
    previous = os.path.join(os.fspath(appdir),"CockpitCompanion","active_route.json")
    if not os.path.exists(ROUTE_PATH) and os.path.isfile(previous):
        try:
            shutil.copyfile(previous,ROUTE_PATH)
        except OSError:
            logger.exception("Could not import the existing route")
    _load_saved_route()
    logger.info("%s %s loaded",TITLE,VERSION)
    return TITLE


def plugin_app(parent):
    """Build the panel. If anything goes wrong, show a one-line notice instead of
    letting EDMC drop the panel silently (the 0.14.0 "missing panel" symptom)."""
    try:
        return _build_panel(parent)
    except Exception:
        logger.exception("%s could not build its panel", TITLE)
    global _app_frame
    global _title_label, _cog_button, _collapse_button, _header_frame, _status_label
    global _current_label, _next_label, _end_label, _done_label, _left_label
    try:
        if _app_frame is not None:
            _app_frame.destroy()
    except tk.TclError:
        pass
    _title_label = _cog_button = _collapse_button = _header_frame = None
    _status_label = None
    global _position_frame, _position_label, _lamp
    _position_frame = _position_label = _lamp = None
    _current_label = _next_label = _end_label = _done_label = _left_label = None
    _route_rows.clear()
    _theme_controls.clear()
    _app_frame = tk.Frame(parent)
    tk.Label(_app_frame, text=f"{TITLE} {VERSION}: panel failed to start.\nSee the EDMC debug log.",
             justify=tk.CENTER).grid(row=0, column=0)
    _app_frame.columnconfigure(0, weight=1)
    return _app_frame


def _build_panel(parent):
    global _app_frame, _header_frame, _title_label, _cog_button, _collapse_button
    global _current_label, _next_label, _end_label, _done_label, _left_label
    global _copy_current_button, _copy_next_button, _copy_end_button, _status_label, _stopped
    _stopped = False
    _route_rows.clear()
    _theme_controls.clear()
    _app_frame = tk.Frame(parent)
    _app_frame.columnconfigure(0,weight=1)
    _header_frame = tk.Frame(_app_frame)
    _header_frame.grid(row=0,column=0)
    _title_label = tk.Label(_header_frame,text=TITLE)
    _title_label.pack(side=tk.LEFT)
    _cog_button = tk.Button(_header_frame,text="\u2699",relief=tk.FLAT,bd=0,padx=0,pady=0,
                            cursor="hand2",command=_show_settings_menu)
    _cog_button.pack(side=tk.LEFT)

    def collapse():
        _settings["collapsed"] = not _settings.get("collapsed")
        _save_settings()
        _refresh_route_label()
    _collapse_button = tk.Button(_app_frame,text="\U0001f53c",command=collapse)
    _collapse_button.grid(row=0,column=0,sticky=tk.NE)

    block = tk.Frame(_app_frame)           # Jumps line + progress bar, centred
    block.grid(row=1,column=0,sticky=tk.EW)
    _route_rows.append(block)
    progress = tk.Frame(block)
    progress.pack()
    _build_route_bar(block, progress)
    def piece(text="",command=None):
        label = tk.Label(progress,text=text,padx=0,bd=0)
        label.pack(side=tk.LEFT)
        if command:
            label.configure(cursor="hand2",takefocus=True)
            _theme_controls.append(label)
            for sequence in ("<Button-1>","<Return>","<space>"):
                label.bind(sequence,lambda event,action=command:action())
        return label
    piece("Jumps ")
    piece("Complete",_show_completed)
    _done_label = piece()
    piece("Left",_show_remaining)
    _left_label = piece()
    _build_position(progress)

    def waypoint(row,getter):
        line = tk.Frame(_app_frame)
        line.grid(row=row,column=0,sticky=tk.W)
        label = tk.Label(line,anchor=tk.W)
        label.pack(side=tk.LEFT)
        copy = _IconButton(line,"copy",lambda:_copy_clicked(getter),label,_cog_button)
        copy.pack(side=tk.LEFT,padx=(4,0))
        _route_rows.append(line)
        return label,copy
    _current_label,_copy_current_button = waypoint(2,_current_system)
    _next_label,_copy_next_button = waypoint(3,_next_system)
    _end_label,_copy_end_button = waypoint(4,_end_system)
    _build_scan_label(5)
    _status_label = tk.Label(_app_frame,anchor=tk.W,wraplength=320)
    _status_label.grid(row=6,column=0,sticky=tk.EW)
    _status_label.grid_remove()
    top = _app_frame.winfo_toplevel()
    for sequence in ("<<ThemeChanged>>","<<NavigatorThemeChanged>>"):
        _theme_bindings.append((top,sequence,top.bind(sequence,_theme_event,add="+")))
    _app_frame.bind("<Map>",_theme_event,add="+")
    _refresh_route_label()
    _theme_event()
    return _app_frame


def journal_entry(cmdr,is_beta,system,station,entry,state):
    global _last_loadout
    if _stopped:
        return
    if entry.get("event")=="Loadout":
        _last_loadout = dict(entry)
    _note_plotted_route(entry, state)
    _note_star_pos(system, entry, state)
    _note_fuel(entry)
    _note_materials(state)
    actual = system or state.get("SystemName")
    if entry.get("event") in ("Location","FSDJump","CarrierJump"):
        actual = entry.get("StarSystem") or actual
    if actual:
        _snapshot["location"] = {"system_name":actual}
    _snapshot["ship"] = _copy_present(state,("ShipType","ShipName","ShipIdent"))
    _update_route_progress(actual,on_jump=entry.get("event")=="FSDJump")
    _save()


def plugin_stop():
    global _stopped, _theme_pending, _status_expiry
    _stopped = True
    if _plot_close_callback is not None:
        _plot_close_callback()
    if _systems_popup is not None:
        try: _systems_popup.destroy()
        except tk.TclError: pass
    if _app_frame is not None:
        for callback in (_theme_pending,_status_expiry):
            if callback is not None:
                try: _app_frame.after_cancel(callback)
                except tk.TclError: pass
    _theme_pending = _status_expiry = None
    for top,sequence,binding in _theme_bindings:
        try: top.unbind(sequence,binding)
        except tk.TclError: pass
    _theme_bindings.clear()
    _theme_controls.clear()
