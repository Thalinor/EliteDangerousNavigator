"""Neutron Highway Navigator EDMC plugin."""
