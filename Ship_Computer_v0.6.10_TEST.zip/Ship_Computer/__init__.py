"""Ship Computer - EDMC package plugin (Navigator suite)."""
