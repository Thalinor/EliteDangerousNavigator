"""Systems Navigator — EDMC plugin in the Navigator suite."""
