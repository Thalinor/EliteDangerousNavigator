"""Ship Radio EDMC plugin (Navigator suite)."""
