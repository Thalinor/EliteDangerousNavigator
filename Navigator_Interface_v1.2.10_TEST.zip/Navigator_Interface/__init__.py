"""Navigator Interface - package marker.

Being a package makes EDMC load this plugin before the other plugins, and lets
the Navigator suite's plugins import it by name (import Navigator_Interface).
"""
