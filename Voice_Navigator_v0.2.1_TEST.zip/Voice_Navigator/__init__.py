"""Voice Navigator: offline voice macros for Elite Dangerous."""
__version__ = "0.2.1"
