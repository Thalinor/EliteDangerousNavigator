"""Event-driven popup attachment."""
import sys


def attach_window(window, app):
    """Delegate generic popup styling/sizing to required Navigator Interface."""
    for module in tuple(sys.modules.values()):
        if module is None:
            continue
        path = str(getattr(module, '__file__', '') or '').replace('\\', '/').casefold()
        if not path.endswith('/navigator_interface/load.py'):
            continue
        hook = getattr(module, 'navigator_attach_window', None)
        try:
            if callable(hook):
                if hook(window) is not False:
                    return
        except Exception as error:
            app.log('Shared window styling unavailable: ' + str(error))
    if not getattr(app, '_interface_notice_shown', False):
        app._interface_notice_shown = True
        app.log('Install or enable Navigator Interface for shared window styling and saved positions.')

